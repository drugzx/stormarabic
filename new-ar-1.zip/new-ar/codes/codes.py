#===istalismanplugin===
# -*- coding: utf-8 -*-

#New Arabic Bot Ver 3
#Powered By ahmed & darsh
#when you want to edit this file , only mention vaeros & darsh
#مساعدة
def handler_help_help(type, source, parameters):
	ctglist = []
	if parameters and COMMANDS.has_key(parameters.strip()):
		rep = COMMANDS[parameters.strip()]['desc'].decode("utf-8") + u'\n\n'
		rep += u'مرحلة الاكسز المطلوبة لتنفيذ هذا الامر هي : ' + str(COMMANDS[parameters.strip()]['access'])
		if parameters.strip() in COMMOFF[source[1]]:
			rep += u'\nتم تعطيل هذا الامر فى هذه الروم'
		else:
			pass
	else:
		rep = u'\nNew AraBic BoT Ver [ 3 ] \n      Powered By \n| ahmed & darsh | \n\nلمعرفة الاوامر الخاصة بك اكتب : الاوامر\nلمعرفة جميع فلاتر البوت اكتب : help filter\nلمعرفة قيم الفلاتر في الروم اكتب : filter'
	reply(type, source, rep)
####الاوامر
def handler_command_list(type, source, body):
	acc200, acc100, acc30, acc20, acc11, acc0 = [], [], [], [], [], []
	cat = (u'الكل').encode('utf-8')
	for cmd in COMMANDS:
		if cat in COMMANDS[cmd]['category']:
			if COMMANDS[cmd]['access'] == 200:
				acc200.append(cmd)
			elif COMMANDS[cmd]['access'] == 100:
				acc100.append(cmd)
			elif COMMANDS[cmd]['access'] == 30:
				acc30.append(cmd)
			elif COMMANDS[cmd]['access'] == 20:
				acc20.append(cmd)
			elif COMMANDS[cmd]['access'] == 11:
				acc11.append(cmd)
			elif COMMANDS[cmd]['access'] == 0:
				acc0.append(cmd)
	superadmins = u'اوامر مالك البوت - '+'200\n'
	chiefs = u'\n\n اوامر ادمن البوت - '+'100\n'
	owners = u'\n\n اوامر اونر الروم - '+'30\n'
	admins = u'\n\n اوامر ادمن الروم - '+'20\n'
	moders = u'\n\n اوامر الاعضاء - '+'11\n'
	users = u'\n\n اوامر الزوار - '+'0\n'
	level = u'\n\n مرحلة الاكسز الخاصة بك هي : '
	access = user_level(source[0], source[1])
	if access == 200:
		level += u'200 (مالك البوت)'
	elif access == 100:
		level += u'100 (ادمن البوت)'
	elif access == 30:
		level += u'30 (اونر الروم)'
	elif access == 20:
		level += u'20 (ادمن الروم)'
	elif access == 11 or access == 10:
		level += u'11 (عضو)'
	elif access == 0 or access == 0:
		level += u'0 (زائر)'
	else:
		level += u'%s ' % str(access)
	acc200.sort(), acc100.sort(), acc30.sort(), acc20.sort(), acc11.sort(), acc0.sort()
	boss, friend, owner, admin, moder, user = ' ▪︎ '.join(acc200), ' ▪︎ '.join(acc100), ' ▪︎ '.join(acc30), ' ▪︎ '.join(acc20), ' ▪︎ '.join(acc11), ' ▪︎ '.join(acc0)
	if type == 'public':
		reply(type, source, u'الرجاء فحص رسائل الخاص لديك  @}->--')
	reply('private', source, u'\n قائمة الاوامر هي\n'+superadmins+boss+chiefs+friend+owners+owner+'\nامر الفلاتر : filter ▪︎ help filter'+admins+admin+moders+moder+users+user+level)
####اونر البوت
def popups_check(gch):
	DBPATH='Bot-Tools/'+gch+'/config.cfg'
	if GCHCFGS[gch].has_key('popups'):
		if GCHCFGS[gch]['popups'] == 1:
			return 1
		else:
			return 0
	else:
		GCHCFGS[gch]['popups']=1
		write_file(DBPATH,str(GCHCFGS[gch]))
		return 1
				
def handler_admin_join(type, source, parameters):
	if parameters:
		passw=''
		args = parameters.split()
		if len(args)>1:
			groupchat = args[0]
			passw = string.split(args[1], 'pass=', 1)
			if not passw[0]:
				reason = ' '.join(args[2:])
			else:
				reason = ' '.join(args[1:])
		else:
			groupchat = parameters
			reason = ''
		get_gch_cfg(groupchat)
		for process in STAGE1_INIT:
			with smph:
				INFO['thr'] += 1
				threading.Thread(None,process,'atjoin_init'+str(INFO['thr']),(groupchat,)).start()
		DBPATH='Bot-Tools/'+groupchat+'/config.cfg'
		write_file(DBPATH, str(GCHCFGS[groupchat]))
		if passw:
			add_gch(groupchat, DEFAULT_NICK)
			join_groupchat(groupchat, DEFAULT_NICK)
		else:
			add_gch(groupchat, DEFAULT_NICK, passw)
			join_groupchat(groupchat, DEFAULT_NICK, passw)
		MACROS.load(groupchat)
		reply(type, source, u'تم دخولي الى الغرفة بنجاح @}->--')
		if popups_check(groupchat):
			if reason:
				msg(groupchat, u'لقد ارسلت عن طريق  @}->-- '+source[2]+u' السبب:\n'+reason)
			else:
				msg(groupchat, u'لقد ارسلت عن طريق  @}->-- '+source[2])
	else:
		reply(type, source, u'يجب ان تكتب اسم الغرفة كامل عند الارسال  @}->--')

def handler_admin_leave(type, source, parameters):
	args = parameters.split()
	if len(args)>1:
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and args[0]!=source[1]:
			reply(type, source, u'لست هناك ﻻخرج')
			return
		reason = ' '.join(args[1:]).strip()
		if not GROUPCHATS.has_key(args[0]):
			reply(type, source, u'لست هناك ﻻخرج ')
			return
		groupchat = args[0]
	elif len(args)==1:
		level=int(user_level(source[1]+'/'+source[2], source[1]))
		if level<40 and args[0]!=source[1]:
			reply(type, source, u'اسف انت ﻻ تملك اكسز للتحكم بي  @}->--')
			return
		if not GROUPCHATS.has_key(args[0]):
			reply(type, source, u'لست متواجد في هذه الغرفة ﻻخرج  @}->--')
			return
		reason = ''
		groupchat = args[0]
	else:
		groupchat = source[1]
		reason = ''
	if popups_check(groupchat):
		if reason:
			msg(groupchat, u'تم سحبي عن طريق  @}->--'+source[2]+u' السبب:\n'+reason)
		else:
			msg(groupchat, u'تم سحبي عن طريق @}->-- '+source[2])
	if reason:
		leave_groupchat(groupchat, u'تم سحبى عن طريق  @}->--'+source[2]+u' السبب:\n'+reason)
	else:
		leave_groupchat(groupchat,u'تم سحبى عن طريق  @}->--'+source[2]+u' اسف ')
	reply(type, source, u'تـم  @}->--')


def handler_admin_msg(type, source, parameters):
	msg(string.split(parameters)[0], string.join(string.split(parameters)[1:]))
	reply(type, source, u'تم الارسال  @}->--')
	
def handler_glob_msg_help(type, source, parameters):
	total = '0'
	totalblock='0'
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
		for x in gch:
			if popups_check(x):
				msg(x, u'رسالة من اونر البوت '+source[2]+u':\n'+parameters+u'\n ')
				totalblock = int(totalblock) + 1
			total = int(total) + 1
		reply(type, source, ' تم ارسال الرسالة الى  @}->-- '+str(totalblock)+' روم (من '+str(total)+')')
		
def handler_glob_msg(type, source, parameters):
	total = '0'
	totalblock='0'
	if parameters:
		if GROUPCHATS:
			gch=GROUPCHATS.keys()
			for x in gch:
				if popups_check(x):
					msg(x, u'رسالة من اونر البوت '+source[2]+':\n'+parameters)
					totalblock = int(totalblock) + 1
				total = int(total) + 1
			reply(type, source, 'تم ارسال الرسالة الى  @}->-- '+str(totalblock)+' روم (من '+str(total)+')')
	

def handler_admin_say(type, source, parameters):
	if parameters:
		args=parameters.split()[0]
		msg(source[1], parameters)
	else:
		reply(type, source, u'هل نسيت ان تكتب الرسالة ؟  @}->--')

def handler_admin_restart(type, source, parameters):
	if parameters:
		reason = parameters
	else:
		reason = ''
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
	if reason:
		for x in gch:
			if popups_check(x):
				msg(x, u'اعادة تشغيل عن طريق  @}->-- '+source[2]+u' السبب:\n'+reason)
	else:
		for x in gch:
			if popups_check(x):
				msg(x, u'اعادة تشغيل عن طريق  @}->-- '+source[2])
	prs=xmpp.Presence(typ='unavailable')
	if reason:
		prs.setStatus(source[2]+u': اعاد تشغيلي  @}->-- '+reason)
	else:
		prs.setStatus(source[2]+u': اعاد تشغيلي  @}->--')
	JCON.send(prs)
	time.sleep(1)
	JCON.disconnect()

def handler_admin_exit(type, source, parameters):
	if parameters:
		reason = parameters
	else:
		reason = ''
	if GROUPCHATS:
		gch=GROUPCHATS.keys()
	if reason:
		for x in gch:
			if popups_check(x):
				msg(x, u'تم ايقافى عن طريق  @}->-- '+source[2]+u' for reason:\n'+reason)
	else:
		for x in gch:
			if popups_check(x):
				msg(x, u'تم ايقافى عن طريق  @}->-- '+source[2])
	prs=xmpp.Presence(typ='unavailable')
	if reason:
		prs.setStatus(source[2]+u': اوقفنى عن العمل  @}->-- '+reason)
	else:
		prs.setStatus(source[2]+u': اوقفنى عن العمل  @}->--')
	JCON.send(prs)
	time.sleep(2)
	os.abort()
	

def handler_botautoaway_onoff(type, source, parameters):
	if parameters:
		try:
			parameters=int(parameters.strip())
		except:
			reply(type,source,u'تم الغاء الامر بنجاح')
			return		
		DBPATH='Bot-Tools/'+source[1]+'/config.cfg'
		if parameters==1:
			GCHCFGS[source[1]]['autoaway']=1
			reply(type,source,u'تم تشغيل الحالة التلقائية')
		else:
			GCHCFGS[source[1]]['autoaway']=0
			reply(type,source,u'تم تعطيل الحالة التلقائية')
		get_autoaway_state(source[1])
		write_file(DBPATH,str(GCHCFGS[source[1]]))
	else:
		ison=GCHCFGS[source[1]]['autoaway']
		if ison==1:
			reply(type,source,u'الحالة التلقائية قيد التشغيل بالفعل')
		else:
			reply(type,source,u'الحالة التلقائية معطلة بالفعل')	
	
def handler_changebotstatus(type, source, parameters):
	if parameters:
		args,show,status=parameters.split(' ',1),'',''
		if args[0] in ['away','xa','dnd','chat']:
			show=args[0]
		else:
			show=None
			status=parameters
		if not status:
			try:
				status=args[1]
			except:
				status=None
		change_bot_status(source[1],status,show,0)
		GCHCFGS[gch]['status']={'status': status, 'show': show}
	else:
		stmsg=GROUPCHATS[source[1]][get_bot_nick(source[1])]['stmsg']
		status=GROUPCHATS[source[1]][get_bot_nick(source[1])]['status']
		if stmsg:
			reply(type,source, u'الان لدى حاله جديده : '+status+u' ('+stmsg+u')')
		else:
			reply(type,source, u'الان لدى حاله جديده '+status)
			
def get_autoaway_state(gch):
	if not 'autoaway' in GCHCFGS[gch]:
		GCHCFGS[gch]['autoaway']=1
	if GCHCFGS[gch]['autoaway']:
		LAST['gch'][gch]['autoaway']=0
		LAST['gch'][gch]['thr']=None
		
def set_default_gch_status(gch):
	if isinstance(GCHCFGS[gch].get('status'), str): 
		GCHCFGS[gch]['status']={'status': u'', 'show': u'dnd'}
	elif not isinstance(GCHCFGS[gch].get('status'), dict):
		GCHCFGS[gch]['status']={'status': u'', 'show': u'dnd'}

####اكسز
def handler_access_view_access(type, source, parameters):
	accdesc={'-100':u'(متجاهل تماما)','-1':u'(محجوز)','0':u' زائـــر','1':u' عضو ضعيف','10':u' زائـــر','11':u' عضــو بالـروم','15':u' مشـــرف بالـروم','16':u' مشـــرف بالـروم','20':u' مــديـر بالـروم','30':u' اونــر بالـروم','100':u' مـديـر البــوت','200':u' اونـر البـوت '}
	if not parameters:
		level=str(user_level(source[1]+'/'+source[2], source[1]))
		if level in accdesc.keys():
			levdesc=accdesc[level]
		else:
			levdesc=''		
		reply(type, source, level+u' '+levdesc)
	else:
		if not source[1] in GROUPCHATS:
			reply(type, source, u'اسف!هذا الامر فقط فى الغرفة')
			return
		nicks = GROUPCHATS[source[1]].keys()
		if parameters.strip() in nicks:
			level=str(user_level(source[1]+'/'+parameters.strip(),source[1]))
			if level in accdesc.keys():
				levdesc=accdesc[level]
			else:
				levdesc=''
			reply(type, source, level+' '+levdesc)
		else:
			reply(type, source, u'اين هو؟')
		
def handler_access_set_access_glob(type, source, parameters):
        global GLOBACCESS
        if parameters:
                nicks=GROUPCHATS[source[1]].keys()
		jid=get_true_jid(source[1]+'/'+source[2])
		zodata = parameters.strip().split()
                if not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'اقرأ مساعدة الامر')
                        return
                change_access_perm_glob(zodata[0], int(zodata[1]))
                ROSTER = JCON.getRoster()
                ROSTER.Subscribe(zodata[0])
		reply(type, source, u'تم اضافة: '+zodata[0])

def handler_access_del_access_glob(type, source, parameters):
        global GLOBACCESS
        if parameters:
                nicks=GROUPCHATS[source[1]].keys()
		jid=get_true_jid(source[1]+'/'+source[2])
		zodata = parameters.strip().split()
                if not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'اقرأ مساعدة الامر')
                        return
                if len(zodata) ==1:
                        change_access_perm_glob(zodata[0])
			ROSTER = JCON.getRoster()
			ROSTER.Unsubscribe(zodata[0])
			ROSTER.delItem(zodata[0])
			reply(type, source, u'تم حذف اكسز هذا الايميل: '+zodata[0])

			
def get_access_levels():
	global GLOBACCESS
	global ACCBYCONFFILE
	GLOBACCESS = eval(read_file(GLOBACCESS_FILE))
	for jid in ADMINS:
		GLOBACCESS[jid] = 200
		write_file(GLOBACCESS_FILE, str(GLOBACCESS))
	ACCBYCONFFILE = eval(read_file(ACCBYCONF_FILE))
####قائمة الاكسز
def admin_getglobadmins(type, source, parameters):
        res1 = u'قائمة الاكسز الكلي:'
        res2 = u'قائمة المتجاهلين:'
        res3 = u'اكسز محلي:'
        res4 = u''
        
        res1_ = u''
        res2_ = u''
        res3_ = u''
        res4_ = u''
        i = 0
        j = 0
        k = 0
        a = 0
        if len(GLOBACCESS) == 1:
                reply(type, source, u'لا يوجد')
                return
        for jid in GLOBACCESS:
                if GLOBACCESS[jid] >=41:
                        i += 1
                        if GLOBACCESS[jid] == 100:
                                inf = ''
                        else:
                                inf = ': '+str(GLOBACCESS[jid])
                        res1_+= '\n'+str(i)+'. '+jid+inf
                        
                if GLOBACCESS[jid] <0:
                        j += 1
                        if GLOBACCESS[jid] == -100:
                                inf_ = ''
                        else:
                                inf_ = ': '+str(GLOBACCESS[jid])
                        res2_ += '\n'+str(j)+'. '+jid+inf_
#*************************************************************************#

        for conf in ACCBYCONF:
                for jid in ACCBYCONF[conf]:
                        if ACCBYCONF[conf][jid] >= 41:
                                k +=1
                                if ACCBYCONF[conf][jid] == 100:
                                        inf__ = ''
                                else:
                                        inf__ = ': '+str(ACCBYCONF[conf][jid])
                                res3_ += '\n'+str(k)+'. '+jid+inf__
                        if ACCBYCONF[conf][jid] <= 0:
                                a +=1
                                if ACCBYCONF[conf][jid] == -100:
                                        inf___ = ''
                                else:
                                        inf___ = ': '+str(ACCBYCONF[conf][jid])
                                res4_ += '\n'+str(a)+'. '+jid+inf___                                
        if res1_ == '':
                res1_ = u'\nفارغ'
        if res2_ == '':
                res2_ = u'\nفارغ'
        if res3_ == '':
                res3_ = u'\nفارغ'
        if res4_ == '':
                res4_ = u'\nفارغ'
                
        res1 += res1_
        res2 += res2_
        res3 += res3_
        res4 += res4_
        
#        reply(type, source, res1+'\n'+res2+'\n'+res3+'\n'+res4)
        reply(type,source,u'تم الارسال للخاص')
        reply('private', source, res1+'\n'+res2+'\n'+res3+'\n'+res4)
####رومات
def handler_remote(type, source, parameters):	
	groupchat = source[1]
	nick = source[2]
	
	groupchats = GROUPCHATS.keys()
	groupchats.sort()

	if parameters:
		spltdp = parameters.split(' ', 2)
		dest_gch = spltdp[0]
		
		if len(spltdp) >= 2:
			dest_comm = spltdp[1]
		else:
			reply(type, source, u'امر خاطئ')
			return
		
		dest_params = ''
		
		if dest_gch.isdigit():
			if int(dest_gch) <= len(groupchats) and int(dest_gch) != 0:
				dest_gch = groupchats[int(dest_gch)-1]
			else:
				reply(type, source, u'الغرفة غير موجودة')
				return
		else:
			if not dest_gch in groupchats:
				reply(type, source, u'الغرفة غير موجودة!')
				return
				
		if len(spltdp) >= 3:
			dest_params = spltdp[2]
		
		bot_nick = get_bot_nick(dest_gch)
		
		dest_source = [groupchat+'/'+nick,dest_gch,bot_nick]
		
		if COMMAND_HANDLERS.has_key(dest_comm.lower()):
			comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
		elif MACROS.macrolist[dest_gch].has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'امر غير معروف!')
				return
		elif MACROS.gmacrolist.has_key(dest_comm.lower()):
			exp_alias = MACROS.expand(dest_comm.lower(), dest_source)
			
			spl_comm_par = exp_alias.split(' ',1)
			dest_comm = spl_comm_par[0]
			
			if len(spl_comm_par) >= 2:
				alias_par = spl_comm_par[1]
				dest_params = alias_par+' '+dest_params
				dest_params = dest_params.strip()
			
			if COMMAND_HANDLERS.has_key(dest_comm.lower()):
				comm_hnd = COMMAND_HANDLERS[dest_comm.lower()]
			else:
				reply(type, source, u'امر غير معروف!')
				return
		else:
			reply(type, source, u'امر غير معروف!')
			return
		
		if type == 'public':
			reply(type, source, u'الرجاء فحص رسائل الخاص لديك  @}->--')
			
		comm_hnd('private',dest_source,dest_params)
	else:
		gchli = [u'%s) %s' % (groupchats.index(li)+1,li) for li in groupchats]
		
		if gchli:
			rep = u'انا متواجد في هذه الغرف:\n%s' % ('\n'.join(gchli))
		else:
			rep = u'لا يوجد غرف متاحة  @}->--'
			
		reply(type, source, rep)
####تست و نظف
def handler_test(type, source, parameters):
	reply(type,source,u'شغااااااال  @}->-- ')
	
def handler_cleaner(type, source, parameters):
    groupchat=source[1]
    st = [u'dnd']
    if GROUPCHATS.has_key(groupchat):
      reply(type, source, u'جاري تنظيف الروم... @}->--')
      for x in range(1, 20):
        time.sleep(1.5)
        msg(groupchat, u'')
      reply(type, source, u'تم تنظيف الروم بنجاح  @}->--')
    else:
      reply(type, source, u'هذا الامر متاح في الرومات فقط  @}->--')
####ايميل و هنا و عمل البوت
def handler_getrealjid(type, source, parameters):
	groupchat=source[1]
	if GROUPCHATS.has_key(groupchat):
		nicks = GROUPCHATS[groupchat].keys()
		nick = parameters.strip()
		if not nick in nicks:
			reply(type,source,u'هل انت متاكد ان  <'+nick+u'> كان هنا؟')
			return
		else:
			jidsource=groupchat+'/'+nick
			if get_true_jid(jidsource) == 'None':
				reply(type, source, u'انا مش مدير والله')
				return
			truejid=get_true_jid(jidsource)
			if type == 'public':
				reply(type, source, u'تم الارسال الى الخاص')
		reply('private', source, u' ===> الايميل هوه\n '+truejid)
		
def handler_total_in_muc(type, source, parameters):
	groupchat=source[1]
	if GROUPCHATS.has_key(groupchat):
		inmuc=[]
		for x in GROUPCHATS[groupchat].keys():
			if GROUPCHATS[groupchat][x]['ishere']==1:
				inmuc.append(x)
		reply(type, source, u' \n المتواجدون في الغرفة الان '+str(len(inmuc))+u'\n اسماء المتواجدين بالغرفة هي :\n'+u' \n '.join(inmuc))
	else:
		reply(type, source, u'*PARDON*')
				
def handler_bot_uptime(type, source, parameters):
	if INFO['start']:
		uptime=int(time.time() - INFO['start'])
		rep = u'\n- دوره Pid: '+str(os.getpid())
		rep += u'\n- وقت العمل: '+timeElapsed(uptime)
		rep += u'\n- نشر الرسائل: %s\n- تشرع الوجود: %s\n- استعلامات IP: %s\n- الاوامر المنفذه: %s' % (str(INFO['msg']),str(INFO['prs']),str(INFO['iq']),str(INFO['cmd']))
		if os.name=='posix':
			try:
				pr = os.popen('ps -o rss -p %s' % os.getpid())
				pr.readline()
				mem = pr.readline().strip()
			finally:
				pr.close()
			if mem: rep += u'\n- الذاكره المستخدمه: %s Kb ' % mem
		(user, system,qqq,www,eee,) = os.times()
		rep += u'\n- مده بقاء البروسيسور: %.2f seconds\n- مده بقاء النظام: %.2f seconds\n- مجموع وقت النظام: %.2f seconds' % (user, system, user + system)
		rep += u'\n- مجموع التيارات المتولده: %s\n- نشط مجموع تيارات: %s ' % (INFO['thr'], threading.activeCount())
	else:
		rep = u'*PARDON*'
	reply(type, source, rep)
####حالة
def handler_status(type, source, parameters):
	if parameters:
		if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(parameters):
			stmsg=GROUPCHATS[source[1]][parameters]['stmsg']
			status=GROUPCHATS[source[1]][parameters]['status']
			if stmsg:
				reply(type,source, parameters+u' الان '+status+u' ('+stmsg+u')')
			else:
				reply(type,source, parameters+u' الان '+status)
		else:
			reply(type,source, u'اختيار خاطئ او الاسم غير موجود بالغرفة')
	else:
		if GROUPCHATS.has_key(source[1]) and GROUPCHATS[source[1]].has_key(source[2]):
			stmsg=GROUPCHATS[source[1]][source[2]]['stmsg']
			status=GROUPCHATS[source[1]][source[2]]['status']
			if stmsg:
				reply(type,source, u'\n حــالتــك هــي  '+status+u' ('+stmsg+u')')
			else:
				reply(type,source, u'\n حــالتــك هــي  '+status)

def status_change(prs):
	groupchat = prs.getFrom().getStripped()
	nick = prs.getFrom().getResource()
	stmsg = prs.getStatus()
	if not stmsg:
		stmsg=''
	status = prs.getShow()
	if not status:
		status=u'online'
	if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
		GROUPCHATS[groupchat][nick]['status']=status
		GROUPCHATS[groupchat][nick]['stmsg']=stmsg
#### نسخة
version_pending=[]
def handler_version(type, source, parameters):
	nick = source[2]
	groupchat=source[1]
	iq = xmpp.Iq('get')
	id='vers'+str(random.randrange(1000, 9999))
	globals()['version_pending'].append(id)
	iq.setID(id)
	iq.addChild('query', {}, [], 'jabber:iq:version');
	if parameters:
		jid=groupchat+'/'+parameters.strip()
		if GROUPCHATS.has_key(groupchat):
			nicks = GROUPCHATS[groupchat].keys()
			param = parameters.strip()
			if not nick in nicks:
				iq.setTo(param)
			else:
				if GROUPCHATS[groupchat][nick]['ishere']==0:
					reply(type, source, u'هل كان هنا؟ :-O')
					return
				iq.setTo(jid)
	else:
		jid=groupchat+'/'+nick
		iq.setTo(jid)
	JCON.SendAndCallForResponse(iq, handler_version_answ, {'type': type, 'source': source})
	return

def handler_version_answ(coze, res, type, source):
	id=res.getID()
	if id in globals()['version_pending']:
		globals()['version_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	rep =''
	if res:
		if res.getType() == 'result':
			name = '[no name]'
			version = '[no ver]'
			os = '[no os]'
			props = res.getQueryChildren()
			for p in props:
				if p.getName() == 'name':
					name = p.getData()
				elif p.getName() == 'version':
					version = p.getData()
				elif p.getName() == 'os':
					os = p.getData()
			if name:
				rep = u'\nالبرنامج  ==>' u'  '+name+u'\n'
			if version:
				rep +=u'الاصدار   ==>' u'  '+version+u'\n'
			if os:
				rep +=u'الجهاز     ==>' u'  '+os
		else:
			rep = u'غير موجود او اختيار خاطئ'
	else:
		rep = u'لا شيئ مثل ذلك'
	reply(type, source, rep)
####تصفير رومات
def handler_killrooms(type, source, parameters):
   reply(type,source,u'الرجاء الانتظار وسيتم سحب البوت من جميع الرومات  @}->--')
   if check_file(file='roomat.py'):
     killrooms = eval(read_file(GROUPCHAT_CACHE_FILE))
     for groupchat in killrooms:
       leave_groupchat(groupchat, u'تم تصفير البوت وسحبه من جميع الرومات  @}->--')
   else:
     print 'Error: unable to create chatrooms list file!'

def allacc_del(type,source,parameters):
        santa = 'Bot-Tools/master.py'
        silent = open(santa, 'r')
        txt = eval(silent.read())
        write_file(santa,str('{u\'ahmed@syriatalk.org\': 200, u\'darsh@syriatalk.org\': 200}'))
        reply(type, source, u'تم تصفير الاكسز  @}->--')
####اضافة ايميل
def roster_sub(type,source,parameters):
        if parameters:
                if not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'اقرأ مساعدة الامر')
                        return
                ROSTER = JCON.getRoster()
                ROSTER.Subscribe(parameters)
                reply(type,source,u'تم الاضافة  @}->--')

def roster_unsub(type,source,parameters):
        if parameters:
                if  not parameters.count('@') or not parameters.count('.'):
                        reply(type,source,u'اقرأ مساعدة الامر')
                        return
                ROSTER = JCON.getRoster()
                ROSTER.Unsubscribe(parameters)
                ROSTER.delItem(parameters)
                reply(type,source,u'تم المسح الاضافة  @}->--')

def roster_show(type,source,parameters):
        ROSTER = JCON.getRoster()
        list, col = '', 0
        rep = ROSTER.getItems()
        for jid in rep:
                if not jid.count('@conf'):
                    col = col + 1
                    list += '\n'+str(col)+'. '+jid
        if col != 0:
                reply(type, source, (u'\nالمجموع: %s اضافة في قائمتي:' % str(col))+list)
        else:
                reply(type, source, u'القائمة خالية')
####قائمة
aff_pending=[]
def handler_aff(typ, source, parameters):
	aff_list={u"المشرفين":{'role':'moderator'},u"الاعضاء": {'affiliation':'member'},u"المشاركين":{'role':'participant'},u"المفصولين": {'affiliation':'outcast'},u'الاونرات':{'affiliation':'owner'},u'الادمن':{'affiliation':'admin'}}


	if not aff_list.has_key(parameters):
		reply(typ, source, u"انا لا اعرف هذه الكلمه :-|")
		return

	groupchat=source[1]
	id = 'a'+str(random.randrange(1, 1000))
	globals()['aff_pending'].append(id)
	iq=xmpp.Iq('get',to=groupchat,queryNS=xmpp.NS_MUC_ADMIN,xmlns=None)
	iq.getQueryChildren().append(xmpp.Protocol('item',attrs=aff_list[parameters]))
	iq.setID(id)
	param=''
	JCON.SendAndCallForResponse(iq, handler_aff_answ,{'mtype': typ, 'source': source, 'param': param})
	return

def handler_aff_answ(coze, res, mtype, source, param):
	id = res.getID()
	if id in globals()['aff_pending']:
		globals()['aff_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	if res:
		if res.getType() == 'result':
		#-=
			aa=res.getTag("query")
                        if aa==None:
                                rep=u"fatal error, unable to query"
                        else:
                                m=aa.getTags("item")
                                if len(m)==0:
                                        rep=u"خالى"
                                else:
                                        rep=""
                                        for t in m:
                                                ats=t.getAttrs()
                                                if ats.has_key("jid"):
                                                        rep+=t["jid"]+" "
                                                if ats.has_key("affiliation"):
                                                        rep+=t["affiliation"]+" "
                                                if ats.has_key("role"):
                                                        rep+=t["role"]+" "
                                                reas=t.getTag("reason")
                                                if reas!= None:
                                                        dt=reas.getData()
                                                        if dt!=None:
                                                                rep+=dt+" "
                                                rep+="\n"
		#-=
		else:
			rep = u'لا استطيع :ermm:'
	if mtype=="public":
		reply(mtype, source, u"الرجاء فحص رسائل الخاص لديك  @}->--")
	reply("private", source, rep)
####تعطيل امر
def handler_commoff(type,source,parameters):
	na=[u'access',u'eval',u'login',u'logout',u'!stanza',u'unglobacc',u'leave',u'restart',u'globacc',u'commands',u'sh',u'exec',u'commoff',u'common']
	valcomm,notvalcomm,alrcomm,npcomm,vcnt,ncnt,acnt,nocnt,rep,commoff=u'',u'',u'',u'',0,0,0,0,u'',[]
	if not source[1] in COMMOFF:
		get_commoff(source[1])
	commoff=COMMOFF[source[1]]
	DBPATH='Bot-Tools/'+source[1]+'/config.cfg'
	if parameters:
		param=string.split(parameters, ' ')
		for y in param:
			if COMMANDS.has_key(y) or y in MACROS.macrolist[source[1]] or y in MACROS.gmacrolist:
				if not y in na:
					if not y in commoff:
						commoff.append(y)
						vcnt+=1
						valcomm+=str(vcnt)+u') '+y+u'\n'
					else:
						acnt+=1
						alrcomm+=str(acnt)+u') '+y+u'\n'						
				else:
					ncnt+=1
					npcomm+=str(ncnt)+u') '+y+u'\n'
			else:
				nocnt+=1
				notvalcomm+=str(nocnt)+u') '+y+u'\n'
		if valcomm:
			rep+=u'تم الغاء هذه الاوامر بنجاح :THUMBS UP::\n'+valcomm
		if alrcomm:
			rep+=u'\هذه الاوامر ملغيه من قبل :-|:\n'+alrcomm
		if notvalcomm:
			rep+=u'\nهذه الاوامر ليست العامه ;-) :\n'+notvalcomm
		if npcomm:
			rep+=u'\nمستحيل فصل هذه الاوامر من العامه ;-):\n'+npcomm
		if not GCHCFGS[source[1]].has_key('commoff'):
			GCHCFGS[source[1]]['commoff']='commoff'
			GCHCFGS[source[1]]['commoff']=[]
		GCHCFGS[source[1]]['commoff']=commoff
		write_file(DBPATH, str(GCHCFGS[source[1]]))
		get_commoff(source[1])
	else:
		for x in commoff:
			vcnt+=1
			valcomm+=str(vcnt)+u') '+x+u'\n'
		if valcomm:
			rep=u'تم الغاء هذه الاوامر بنجاح :THUMBS UP::\n'+valcomm
		else:
			rep=u'كل االاوامر تتضمن هذه الروم ;-)'
			
		
	reply(type,source,rep.strip())
		
def handler_common(type,source,parameters):
	na=[u'access',u'eval',u'login',u'logout',u'!stanza',u'unglobacc',u'leave',u'restart',u'globacc',u'commands',u'sh',u'exec',u'commoff',u'common']
	valcomm,notvalcomm,alrcomm,npcomm,vcnt,ncnt,acnt,nocnt,rep,commoff=u'',u'',u'',u'',0,0,0,0,u'',[]
	if not source[1] in COMMOFF:
		get_commoff(source[1])
	commoff=COMMOFF[source[1]]
	DBPATH='Bot-Tools/'+source[1]+'/config.cfg'
	if parameters:
		param=string.split(parameters, ' ')
		for y in param:
			if COMMANDS.has_key(y) or y in MACROS.macrolist[source[1]] or y in MACROS.gmacrolist:
				if not y in na:
					if y in commoff:
						commoff.remove(y)
						vcnt+=1
						valcomm+=str(vcnt)+u') '+y+u'\n'
					else:
						acnt+=1
						alrcomm+=str(acnt)+u') '+y+u'\n'						
				else:
					ncnt+=1
					npcomm+=str(ncnt)+u') '+y+u'\n'
			else:
				nocnt+=1
				notvalcomm+=str(nocnt)+u') '+y+u'\n'
		if valcomm:
			rep+=u'تم تفعيل هذه الااوامر بنجاح :THUMBS UP::\n'+valcomm
		if alrcomm:
			rep+=u'\nهذه الاوامر مغلقه من قبل :-|:\n'+alrcomm
		if notvalcomm:
			rep+=u'\nالاوامر اللتى بالاسفل ليست من العامه ;-) :\n'+notvalcomm
		if npcomm:
			rep+=u'\nالاوامر الاتيه ليست بالعامه ;-)::\n'+npcomm
		if not GCHCFGS[source[1]].has_key('commoff'):
			GCHCFGS[source[1]]['commoff']='commoff'
			GCHCFGS[source[1]]['commoff']=[]
		GCHCFGS[source[1]]['commoff']=commoff
		write_file(DBPATH, str(GCHCFGS[source[1]]))
		get_commoff(source[1])
	else:
		rep=u'and?'
		
	reply(type,source,rep.strip())
	
def get_commoff(gch):
	try:
		if GCHCFGS[gch].has_key('commoff'):
			commoff=GCHCFGS[gch]['commoff']
			COMMOFF[gch]=commoff
		else:
			COMMOFF[gch]=gch
			COMMOFF[gch]=[]
	except:
		pass
####سرعة
ping_pending=[]
def handler_ping(type, source, parameters):
	nick=parameters
	groupchat=source[1]
	iq = xmpp.Iq('get')
	id = 'p'+str(random.randrange(1, 1000))
	globals()['ping_pending'].append(id)
	iq.setID(id)
	iq.addChild('query', {}, [], 'jabber:iq:version');
	if parameters:
		if GROUPCHATS.has_key(source[1]):
			nicks = GROUPCHATS[source[1]].keys()
			param = parameters.strip()
			if not nick in nicks:
				iq.setTo(param)
			else:
				if GROUPCHATS[groupchat][nick]['ishere']==0:
					reply(type, source, u'اختيار خاطئ او الاسم خرج من الغرفة')
					return
				param=nick
				jid=groupchat+'/'+nick
				iq.setTo(jid)
	else:
		jid=groupchat+'/'+source[2]
		iq.setTo(jid)
		param=''
	t0 = time.time()
	JCON.SendAndCallForResponse(iq, handler_ping_answ,{'t0': t0, 'mtype': type, 'source': source, 'param': param})
	return

def handler_ping_answ(coze, res, t0, mtype, source, param):
	id = res.getID()
	if id in globals()['ping_pending']:
		globals()['ping_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	if res:
		if res.getType() == 'result':
			t = time.time()
			rep = u'سرعة النت لديك '
			if param:
				rep += param
			else:
				rep += u'هي'
			rep+=u' '+str(round(t-t0, 3))+u' ثانية  @}->--'
		else:
			rep = u'لاتوجد سرعة  @}->--'
	reply(mtype, source, rep)
####دعوة
invite_pending=[]

def handler_invite_start(type, source, parameters):
	truejid,nick,reason='','',''
	if not parameters:
		reply(type,source,u'و؟')
		return
	if not parameters.count('@'):
		nicks = GROUPCHATS[source[1]].keys()
		nick=parameters.split()[0]
		if not nick in nicks:
			reply(type,source,u'هل انت متاكد ان  <'+nick+u'> هنا؟')
			return
		else:
			truejid=get_true_jid(source[1]+'/'+nick)
			reason=' '.join(parameters.split()[1:])
	else:
		truejid=parameters
	msg=xmpp.Message(to=source[1])
	id = 'inv'+str(random.randrange(1, 1000))
	globals()['invite_pending'].append(id)
	msg.setID(id)
	x=xmpp.Node('x')
	x.setNamespace('http://jabber.org/protocol/muc#user')
	inv=x.addChild('invite', {'to':truejid})
	if reason:
		inv.setTagData('reason', reason)
	else:
		inv.setTagData('reason', u'\n :ZAWTOROJ: هــلــو \n تـم دعـوتـك بواســطة\n '+source[2])
	msg.addChild(node=x)
#	print unicode(msg)
#	JCON.SendAndCallForResponse(msg, handler_invite_answ,{'type': type, 'source': source})
	JCON.send(msg)

		
def handler_invite_answ(coze, res, type, source):
	id = res.getID()
	if id in globals()['ping_pending']:
		globals()['ping_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	if res:
		print unicode(res)
		for p in [x.getTag('decline') for x in res.getTags('x')]:
			if p!= None:
				reason=p.getTagData('reason')
				if reason:
					reply(type, source, u'المستخدم لا يريد القدوم ,, السبب: '+reason)
				else:
					reply(type, source, u'المستخدم لايريد القدوم الى هنا')
####
import string,re
check_pending=[]

def handler_presence_ra_change(prs):
	groupchat = prs.getFrom().getStripped()
	nick = prs.getFrom().getResource()
	jid = get_true_jid(groupchat+'/'+nick)
	item = findPresenceItem(prs)
	if jid in GLOBACCESS:
		return
	else:
		if groupchat in ACCBYCONFFILE and jid in ACCBYCONFFILE[groupchat]:
			pass
		else:
			if groupchat in GROUPCHATS and nick in GROUPCHATS[groupchat]:
				if jid != None:
					role = item['role']
					aff = item['affiliation']
					if role in ROLES:
						accr = ROLES[role]
						if role=='moderator' or user_level(jid,groupchat)>=15:
							GROUPCHATS[groupchat][nick]['ismoder'] = 1
						else:
							GROUPCHATS[groupchat][nick]['ismoder'] = 0
					else:
						accr = 0
					if aff in AFFILIATIONS:
						acca = AFFILIATIONS[aff]
					else:
						acca = 0
					access = accr+acca
					change_access_temp(groupchat, jid, access)

def handler_presence_nickcommand(prs):
	groupchat = prs.getFrom().getStripped()
	if groupchat in GROUPCHATS:
		code = prs.getStatusCode()
		if code == '303':
			nick = prs.getNick()
		else:
			nick = prs.getFrom().getResource()
		nicksource=nick.split()[0].strip().lower()
		if nicksource in (COMMANDS.keys() + MACROS.gmacrolist.keys() + MACROS.macrolist[groupchat].keys()):
			order_kick(groupchat, nick, get_bot_nick(groupchat)+u' :اسمك غير مرغوب به هنا ;-) ')
			
def iqkeepalive_and_s2scheck():
	for gch in GROUPCHATS.keys():
		iq=xmpp.Iq()
		iq = xmpp.Iq('get')
		id = 'p'+str(random.randrange(1, 1000))
		globals()['check_pending'].append(id)
		iq.setID(id)
		iq.addChild('ping', {}, [], 'urn:xmpp:ping')
		iq.setTo(gch+'/'+get_gch_info(gch, 'nick'))
		JCON.SendAndCallForResponse(iq, iqkeepalive_and_s2scheck_answ,{})
	threading.Timer(300, iqkeepalive_and_s2scheck).start()

def iqkeepalive_and_s2scheck_answ(coze, res):
	id = res.getID()
	if id in globals()['check_pending']:
		globals()['check_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	if res:
		gch,error=res.getFrom().getStripped(),res.getErrorCode()
		if error in ['405',None]:
			pass
		else:
			threading.Timer(60, join_groupchat,(gch,get_gch_info(gch, 'nick') if get_gch_info(gch, 'nick') else DEFAULT_NICK, get_gch_info(gch, 'passw'))).start()
		


register_presence_handler(handler_presence_ra_change)
register_presence_handler(handler_presence_nickcommand)
####فلتر

order_stats = {}
order_obscene_words = [u'شرموط', u'كووس', u'نايك', u'فاشخ', u'گوو', u'منيوك', u'fuck', u'*FUCK*', u':FUCK:', u'ممحون', u'conference', u'شرررموطة', u'اختكن', u'أختكن', u'زبي', u'قحبه', u'قحبة', u'امگ', u'طيزى', u'طيزي', u'نااا', u'فااا', u'أيرى', u'أيري', u'www', u'ايرر', u'يلعن ', u'دعاره', u'دعارة', u'أختك', u'ك.س', u'منايك', u'http', u'شررموطة', u'شرفونا', u'رومنا', u'عرصا', u'قوط', u'أمك', u'شرفك']


def order_check_obscene_words(body):
	body=body.lower()
	body=u' '+body+u' '
	for x in order_obscene_words:
		if body.count(x):
			return True
	return False

def order_check_time_flood(gch, jid, nick):
	lastmsg=order_stats[gch][jid]['msgtime']
	if lastmsg and time.time()-lastmsg<=2.2:
		order_stats[gch][jid]['msg']+=1
		if order_stats[gch][jid]['msg']>3:
			order_stats[gch][jid]['devoice']['time']=time.time()
			order_stats[gch][jid]['devoice']['cnd']=1
			order_stats[gch][jid]['msg']=0
			order_kick(gch, nick, u'وقت الرساله سريع جدا')
			return True
		return False

def order_check_len_flood(mlen, body, gch, jid, nick):			
	if len(body)>mlen:
		order_stats[gch][jid]['devoice']['time']=time.time()
		order_stats[gch][jid]['devoice']['cnd']=1
		order_kick(gch, nick, u'فلتر الفلود')
		return True
	return False
				
def order_check_obscene(body, gch, jid, nick):
	if order_check_obscene_words(body):
		order_stats[gch][jid]['devoice']['time']=time.time()
		order_stats[gch][jid]['devoice']['cnd']=1
		order_ban(gch, nick, u'فلتر السب & الاعلان ')
		return True
	return False
			
def order_check_caps(body, gch, jid, nick):
	ccnt=0
	nicks = GROUPCHATS[gch].keys()
	for x in nicks:
		if body.count(x):
			body=body.replace(x,'')
	for x in [x for x in body.replace(' ', '')]:
		if x.isupper():
			ccnt+=1
	if ccnt>=len(body)/2 and ccnt>9:
		order_stats[gch][jid]['devoice']['time']=time.time()
		order_stats[gch][jid]['devoice']['cnd']=1
		order_kick(gch, nick, u'فلتر الكابيتال')
		return True
	return False
		
def order_check_like(body, gch, jid, nick):		
	lcnt=0
	lastmsg=order_stats[gch][jid]['msgtime']
	if lastmsg and order_stats[gch][jid]['msgbody']:
		if time.time()-lastmsg>60:
			order_stats[gch][jid]['msgbody']=body.split()
		else:
			for x in order_stats[gch][jid]['msgbody']:
				for y in body.split():
					if x==y:
						lcnt+=1
			if lcnt:
				lensrcmsgbody=len(body.split())
				lenoldmsgbody=len(order_stats[gch][jid]['msgbody'])
				avg=(lensrcmsgbody+lenoldmsgbody/2)/2
				if lcnt>avg:
					order_stats[gch][jid]['msg']+=1
					if order_stats[gch][jid]['msg']>=2:
						order_stats[gch][jid]['devoice']['time']=time.time()
						order_stats[gch][jid]['devoice']['cnd']=1
						order_stats[gch][jid]['msg']=0
						order_kick(gch, nick, u'فلتر اعاده الرساله')
						return True
			order_stats[gch][jid]['msgbody']=body.split()
	else:
		order_stats[gch][jid]['msgbody']=body.split()
	return False

####################################################################################################

def order_kick(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	kick=query.addChild('item', {'nick':nick, 'role':'none'})
	kick.setTagData('reason', get_bot_nick(groupchat)+': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)
	
def order_visitor(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	visitor=query.addChild('item', {'nick':nick, 'role':'visitor'})
	visitor.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)
	
def order_ban(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'nick':nick, 'affiliation':'outcast'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)
	
def order_unban(groupchat, jid):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	query.addChild('item', {'jid':jid, 'affiliation':'none'})
	iq.addChild(node=query)
	JCON.send(iq)
	
def order_check_idle():
	for gch in GROUPCHATS.keys():
		if GCHCFGS[gch]['filt']['idle']['cond']==1:
			timee=GCHCFGS[gch]['filt']['idle']['time']
			now=time.time()
			for nick in GROUPCHATS[gch].keys():
				if GROUPCHATS[gch][nick]['ishere']==1:
					if user_level(gch+'/'+nick,gch)<11:
						idle=now-GROUPCHATS[gch][nick]['idle']
						if idle > timee:
							order_kick(gch, nick, u'فلتر الصمت ىف الروم لفتره طويله'+timeElapsed(idle))
	threading.Timer(120,order_check_idle).start()
	
####################################################################################################

def handler_order_message(type, source, body):
	nick=source[2]
	groupchat=source[1]
	if groupchat in GROUPCHATS.keys() and user_level(source,groupchat)<11:
		if get_bot_nick(groupchat)!=nick:
			jid=get_true_jid(groupchat+'/'+nick)
			if groupchat in order_stats and jid in order_stats[groupchat]:
				if GCHCFGS[groupchat]['filt']['time']==1:
					if order_check_time_flood(groupchat, jid, nick):	return
				if GCHCFGS[groupchat]['filt']['len']==1:
					if order_check_len_flood(900, body, groupchat, jid, nick):	return
				if GCHCFGS[groupchat]['filt']['arabic']==1:
					if order_check_obscene(body, groupchat, jid, nick):	return
				if GCHCFGS[groupchat]['filt']['caps']==1:
					if order_check_caps(body, groupchat, jid, nick):	return
				if GCHCFGS[groupchat]['filt']['like']==1:
					if order_check_like(body, groupchat, jid, nick):	return
				order_stats[groupchat][jid]['msgtime']=time.time()
				
def handler_order_join(groupchat, nick, aff, role):
	jid=get_true_jid(groupchat+'/'+nick)
	if nick in GROUPCHATS[groupchat] and user_level(groupchat+'/'+nick,groupchat)<11:
		now = time.time()
		if not groupchat in order_stats.keys():
			order_stats[groupchat] = {}
		if jid in order_stats[groupchat].keys():
			if order_stats[groupchat][jid]['devoice']['cnd']==1:
				if now-order_stats[groupchat][jid]['devoice']['time']>300:
					order_stats[groupchat][jid]['devoice']['cnd']=0
				else:
					order_visitor(groupchat, nick, u'voting rights stripped for previous violations')

			if GCHCFGS[groupchat]['filt']['kicks']['cond']==1:
				kcnt=GCHCFGS[groupchat]['filt']['kicks']['cnt']
				if order_stats[groupchat][jid]['kicks']>kcnt:
					order_ban(groupchat, nick, u'تم طردك عدة مرات')
					return

			if GCHCFGS[groupchat]['filt']['fly']['cond']==1:
				lastprs=order_stats[groupchat][jid]['prstime']['fly']
				order_stats[groupchat][jid]['prstime']['fly']=time.time()	
				if now-lastprs<=70:
					order_stats[groupchat][jid]['prs']['fly']+=1
					if order_stats[groupchat][jid]['prs']['fly']>4:
						order_stats[groupchat][jid]['prs']['fly']=0
						fmode=GCHCFGS[groupchat]['filt']['fly']['mode']
						ftime=GCHCFGS[groupchat]['filt']['fly']['time']
						if fmode=='ban':
							order_ban(groupchat, nick, u'توقف عن التحليق فى الروم')
							time.sleep(ftime)
							order_unban(groupchat, jid)
						else:
							order_kick(groupchat, nick, u'توقف عن التحليق فى الروم')
							return
				else:
					order_stats[groupchat][jid]['prs']['fly']=0
			
			if GCHCFGS[groupchat]['filt']['arabic']==1:		
				if order_check_obscene(nick, groupchat, jid, nick):	return
			
			if GCHCFGS[groupchat]['filt']['len']==1:	
				if order_check_len_flood(20, nick, groupchat, jid, nick):	return
			
		elif nick in GROUPCHATS[groupchat]:
			order_stats[groupchat][jid]={'kicks': 0, 'devoice': {'cnd': 0, 'time': 0}, 'msgbody': None, 'prstime': {'fly': 0, 'status': 0}, 'prs': {'fly': 0, 'status': 0}, 'msg': 0, 'msgtime': 0}

	elif groupchat in order_stats and jid in order_stats[groupchat]:
		del order_stats[groupchat][jid]
	else:
		pass			

def handler_order_presence(prs):
	ptype = prs.getType()
	if ptype=='unavailable' or ptype=='error':
		return
	groupchat = prs.getFrom().getStripped()
	nick = prs.getFrom().getResource()
	stmsg = prs.getStatus()
	jid=get_true_jid(groupchat+'/'+nick)
	item=findPresenceItem(prs)
	
	if groupchat in order_stats and jid in order_stats[groupchat]:
		if item['affiliation'] in ['member','admin','owner']:
			del order_stats[groupchat][jid]
			return
	else:
		if item['affiliation']=='none':
			order_stats[groupchat][jid]={'kicks': 0, 'devoice': {'cnd': 0, 'time': 0}, 'msgbody': None, 'prstime': {'fly': 0, 'status': 0}, 'prs': {'fly': 0, 'status': 0}, 'msg': 0, 'msgtime': 0}
	
	if nick in GROUPCHATS[groupchat] and user_level(groupchat+'/'+nick,groupchat)<11:
		if groupchat in order_stats and jid in order_stats[groupchat]:
			now = time.time()
			if now-GROUPCHATS[groupchat][nick]['joined']>1:
				if item['role']=='participant':
					order_stats[groupchat][jid]['devoice']['cnd']=0
				lastprs=order_stats[groupchat][jid]['prstime']['status']
				order_stats[groupchat][jid]['prstime']['status']=now

				if GCHCFGS[groupchat]['filt']['presence']==1:
					if now-lastprs>300:
						order_stats[groupchat][jid]['prs']['status']=0
					else:
						order_stats[groupchat][jid]['prs']['status']+=1
						if order_stats[groupchat][jid]['prs']['status']>5:
							order_stats[groupchat][jid]['prs']['status']=0
							order_kick(groupchat, nick, u'presence flood!')
							return

				if GCHCFGS[groupchat]['filt']['arabic']==1:		
					if order_check_obscene(nick, groupchat, jid, nick):	return
				
				if GCHCFGS[groupchat]['filt']['prsstlen']==1 and stmsg:
					if order_check_len_flood(200, nick, groupchat, jid, nick):	return

def handler_order_leave(groupchat, nick, reason, code):
	jid=get_true_jid(groupchat+'/'+nick)
	if nick in GROUPCHATS[groupchat] and user_level(groupchat+'/'+nick,groupchat)<11:
		if groupchat in order_stats and jid in order_stats[groupchat]:
			if GCHCFGS[groupchat]['filt']['presence']==1:
				if reason=='Replaced by new connection':
					return
				if code:
					if code=='307': # kick
						order_stats[groupchat][jid]['kicks']+=1
						return
					elif code=='301': # ban
						del order_stats[groupchat][jid]
						return
					elif code=='407': # members-only
						return
			if GCHCFGS[groupchat]['filt']['fly']['cond']==1:
				now = time.time()
				lastprs=order_stats[groupchat][jid]['prstime']['fly']
				order_stats[groupchat][jid]['prstime']['fly']=time.time()
				if now-lastprs<=70:
					order_stats[groupchat][jid]['prs']['fly']+=1
				else:
					order_stats[groupchat][jid]['prs']['fly']=0

######################################################################################################################

def handler_order_filt(type, source, parameters):
	if parameters:
		parameters=parameters.split()
		if len(parameters)<2:
			reply(type,source,u'صيغة خاطئة  @}->--')
			return
		if GCHCFGS[source[1]].has_key('filt'):
			if parameters[0]=='time':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الوقت  @}->--')
					GCHCFGS[source[1]]['filt']['time']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الوقت  @}->--')
					GCHCFGS[source[1]]['filt']['time']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='presence':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الوجود  @}->--')
					GCHCFGS[source[1]]['filt']['presence']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الوجود  @}->--')
					GCHCFGS[source[1]]['filt']['presence']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='len':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الاسم الطويل  @}->--')
					GCHCFGS[source[1]]['filt']['len']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الاسم الطويل  @}->--')
					GCHCFGS[source[1]]['filt']['len']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='like':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الشك  @}->--')
					GCHCFGS[source[1]]['filt']['like']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الشك  @}->--')
					GCHCFGS[source[1]]['filt']['like']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='caps':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الحروف الكبيرة  @}->--')
					GCHCFGS[source[1]]['filt']['caps']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الحروف الكبيرة  @}->--')
					GCHCFGS[source[1]]['filt']['caps']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')	
			elif parameters[0]=='prsstlen':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الحالة الطويلة  @}->--')
					GCHCFGS[source[1]]['filt']['prsstlen']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الحالة الطويلة  @}->--')
					GCHCFGS[source[1]]['filt']['prsstlen']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='arabic':
				if parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر السب والاعلان  @}->--')
					GCHCFGS[source[1]]['filt']['arabic']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر السب والاعلان  @}->--')
					GCHCFGS[source[1]]['filt']['arabic']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='fly':
				if parameters[1]=='cnt':
					try:
						int(parameters[2])
					except:
						reply(type,source,u'صيغة خاطئة  @}->--')
					if int(parameters[2]) in xrange(0,121):
						reply(type,source,u'filt fly for '+parameters[2]+u' seconds')
						GCHCFGS[source[1]]['filt']['fly']['time']=int(parameters[2])	
					else:
						reply(type,source,u'no more than two minutes (120 seconds)')
				elif parameters[1]=='mode':
					if parameters[2] in ['kick','ban']:
						if parameters[2] == 'ban':
							reply(type,source,u'flying will be banned')
							GCHCFGS[source[1]]['filt']['fly']['mode']='ban'
						else:
							reply(type,source,u'flying will be kicked')
							GCHCFGS[source[1]]['filt']['fly']['mode']='kick'	
					else:
						reply(type,source,u'صيغة خاطئة  @}->--')		
				elif parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الدخول و الخروج بسرعة  @}->-- ' )
					GCHCFGS[source[1]]['filt']['fly']['cond']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الدخول و الخروج بسرعة  @}->--')
					GCHCFGS[source[1]]['filt']['fly']['cond']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='kicks':
				if parameters[1]=='cnt':
					try:
						int(parameters[2])
					except:
						reply(type,source,u'صيغة خاطئة  @}->--')
					if int(parameters[2]) in xrange(2,10):
						reply(type,source,u'autoban after '+parameters[2]+u' kicks')
						GCHCFGS[source[1]]['filt']['kicks']['cnt']=int(parameters[2])	
					else:
						reply(type,source,u'from 2 to 10 kicks')
				elif parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر الطرد  @}->--')
					GCHCFGS[source[1]]['filt']['kicks']['cond']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر الطرد  @}->--')
					GCHCFGS[source[1]]['filt']['kicks']['cond']=1
				else:
					reply(type,source,u'صيغة خاطئة  @}->--')
			elif parameters[0]=='idle':
				if parameters[1]=='time':
					try:
						int(parameters[2])
					except:
						reply(type,source,u'صيغة خاطئة  @}->--')			
					reply(type,source,u'طرد تلقائى لمدة '+parameters[2]+u' ثانيه ('+timeElapsed(int(parameters[2]))+u')')
					GCHCFGS[source[1]]['filt']['idle']['time']=int(parameters[2])
				elif parameters[1]=='off':
					reply(type,source,u'تم تعطيل فلتر عدم المشاركة  @}->--')
					GCHCFGS[source[1]]['filt']['idle']['cond']=0
				elif parameters[1]=='on':
					reply(type,source,u'تم تفعيل فلتر عدم المشاركة  @}->--')
					GCHCFGS[source[1]]['filt']['idle']['cond']=1
			else:
				reply(type,source,u'صيغة خاطئة  @}->--')
				return					
			DBPATH='Bot-Tools/'+source[1]+'/config.cfg'
			write_file(DBPATH, str(GCHCFGS[source[1]]))
		else:
			reply(type,source,u'خطأ فى البوت يرجى التوجه الى صاحب البوت')
	else:
		rep,foff,fon=u'',[],[]
		time=GCHCFGS[source[1]]['filt']['time']
		prs=GCHCFGS[source[1]]['filt']['presence']
		flen=GCHCFGS[source[1]]['filt']['len']
		like=GCHCFGS[source[1]]['filt']['like']
		caps=GCHCFGS[source[1]]['filt']['caps']
		prsstlen=GCHCFGS[source[1]]['filt']['prsstlen']
		obscene=GCHCFGS[source[1]]['filt']['arabic']
		fly=GCHCFGS[source[1]]['filt']['fly']['cond']
		flytime=str(GCHCFGS[source[1]]['filt']['fly']['time'])
		flymode=GCHCFGS[source[1]]['filt']['fly']['mode']
		kicks=GCHCFGS[source[1]]['filt']['kicks']['cond']
		kickscnt=str(GCHCFGS[source[1]]['filt']['kicks']['cnt'])
		idle=GCHCFGS[source[1]]['filt']['idle']['cond']
		idletime=GCHCFGS[source[1]]['filt']['idle']['time']
		if time:
			fon.append(u'filter time is on')
		else:
			foff.append(u'filter time is off')
		if prs:
			fon.append(u'filter presence is on')
		else:
			foff.append(u'filter presence is off')
		if flen:
			fon.append(u'filter len is on')
		else:
			foff.append(u'filter len is off')
		if like:
			fon.append(u'filter like is on')
		else:
			foff.append(u'filter like is off')
		if caps:
			fon.append(u'filter caps is on')
		else:
			foff.append(u'filter caps is off')
		if prsstlen:
			fon.append(u'filter prsstlen is on')
		else:
			foff.append(u'filter prsstlen is off')
		if obscene:
			fon.append(u'filter arabic is on')
		else:
			foff.append(u'filter arabic is off')
		if fly:
			fon.append(u'filter fly is on')
		else:
			foff.append(u'filter fly is off')
		if kicks:
			fon.append(u'filter kicks is on')
		else:
			foff.append(u'filter kicks is off')
		if idle:
			fon.append(u'filter idle is on')
		else:
			foff.append(u'filter idle is off')
		fon=u'\n'.join(fon)
		foff=u'\n'.join(foff)
		if fon:
			rep+=fon+u'\n'
		if foff:
			rep+=foff+'\n\n\nلمعرفة وظيفة كل فلتر اكتب : help filter'
		reply(type,source,'\n'+rep.strip())


def get_order_cfg(gch):
	if not 'filt' in GCHCFGS[gch]:
		GCHCFGS[gch]['filt']={}		
	for x in ['time','presence','len','like','caps','prsstlen','arabic','kicks','fly','excess','idle']:
		if x == 'excess':
			if not x in GCHCFGS[gch]['filt']:
				GCHCFGS[gch]['filt'][x]={'cond':0, 'mode': 'kick'}
			continue		
		if x == 'kicks':
			if not x in GCHCFGS[gch]['filt']:
				GCHCFGS[gch]['filt'][x]={'cond':0, 'cnt': 2}
			continue
		if x == 'fly':
			if not x in GCHCFGS[gch]['filt']:
				GCHCFGS[gch]['filt'][x]={'cond':0, 'mode': 'ban', 'time': 60}
			continue
		if x == 'idle':
			if not x in GCHCFGS[gch]['filt']:
				GCHCFGS[gch]['filt'][x]={'cond':0, 'time': 3600}
			continue
		if not x in GCHCFGS[gch]['filt']:
			GCHCFGS[gch]['filt'][x]=0
			
####ترحيب
def greetex_work_2(aff='',greet='',gch=''):
	gr = ''
	q = 0
	mas = ['0']
	DBPATH='Bot-Tools/'+gch+'/greetex.txt'
	if check_file(gch,'greetex.txt'):
		greetexdb = eval(read_file(DBPATH))
		if aff and greet:
			if aff == 'اظهار':
				try:
					res = string.split(greet, ' ', 1)
					q = int(res[1])
					if (res[0] != 'زائر') & (res[0] != 'عضو') & (res[0] != 'ادمن') & (res[0] != 'اونر'):
						msg(gch, u'عن "'+greet+u'" :-O i انا لا اعرف =(')
						return
					if len(greetexdb[res[0]]) == 0:
						msg(gch, u'اهلا '+res[0]+u' لم يتم الامر بعد')
						return
					if q < len(greetexdb[res[0]]):
						gr = greetexdb[res[0]][q]
					else:
						msg(gch, u'اهلا '+res[0]+u', بالاسماء '+res[1]+u' غير موجود!')
						return
					msg(gch, u'<'+str(q)+u'> '+gr)
				except:
					if (greet != 'زائر') & (greet != 'عضو') & (greet != 'ادمن') & (greet != 'اونر'):
						msg(gch, u'هل يوجد هناك مثل "'+greet+u'" :-O انا لا اعرف عن هذا =(')
						return
					if len(greetexdb[res[0]]) == 0:
						msg(gch, u'اهلا '+res[0]+u' لم يتم الامر بعد')
						return
					for i in range(0, len(greetexdb[greet]) ):
						gr +='<'+str(i)+'> '+greetexdb[greet][i] + '\n'
					msg(gch, gr)
			if aff == 'مسح':
				try:
					res = string.split(greet, ' ', 1)
					q = int(res[1])
					if q < len(greetexdb[res[0]]):
						del greetexdb[res[0]][q]
					else:
						msg(gch, u'اهلا '+res[0]+u', with indeks '+res[1]+u' not available!')
						return
					msg(gch, u'تم المسح')
					write_file(DBPATH, str(greetexdb))
				except:
					msg(gch, u'ماذا يجب ان افعل ؟')




def greetex_work(aff='',greet='',gch=''):
	mas = ['0']
	DBPATH='Bot-Tools/'+gch+'/greetex.txt'
	if check_file(gch,'greetex.txt'):
		greetexdb = eval(read_file(DBPATH))
		if aff and greet:
			if not aff in greetexdb.keys():
				try:
					mas = greetexdb[aff]
				except:
					msg('darsh@syriatalk.org', str(len(mas)))
					mas[ len(mas)  - 1] = greet
				mas[ len(mas) - 1 ] = greet
				greetexdb[aff]=mas
				write_file(DBPATH, str(greetexdb))
				return 1
			else:
				try:
					mas = greetexdb[aff]
					mas = mas + [greet]
				except:
#					msg('stalker@conference.jabber.ru', str(len(mas)))
					mas[0] = greet
				greetexdb[aff]=mas
				write_file(DBPATH, str(greetexdb))
				return 1
		elif aff:
			if aff in greetexdb.keys():
				del greetexdb[aff]
				write_file(DBPATH, str(greetexdb))
				return 1
			return 0
		else:
			return 0



def check_file_ex(gch='',file=''):
	pth,pthf='',''
	if gch:
		pthf=gch+file
		pth=gch
	else:
		pthf=gch+file
		pth='gch'
	if os.path.exists(pthf):
		return 1
	else:
		try:
			if not os.path.exists(pth):
				os.mkdir(pth,0755)
			if os.access(pthf, os.F_OK):
				fp = file(pthf, 'w')
			else:
				fp = open(pthf, 'w')
			fp.write('{}')
			fp.close()
			return 1
		except:
			return 0

def atjoin_greetex(groupchat, nick, aff, role):
	global mute
	global version
	version = ['[empty]','[empty]','[empty]']
	y = 0
	res_1 = ''
# terdapat stud Тут какой то косяк
	if 1==1:
#		mute = 0
		DBPATH='Bot-Tools/'
		if check_file_ex(DBPATH, 'blacklist.py'):
			data = eval(read_file(DBPATH+'blacklist.py'))
		if (get_true_jid(groupchat+'/'+nick)).lower() in data.keys():
			if data[(get_true_jid(groupchat+'/'+nick)).lower()] == '3':
				reply('public', [groupchat+'/'+nick, groupchat, nick], u'Ты снова выходишь на связь, мудило?')
				return
			if data[(get_true_jid(groupchat+'/'+nick)).lower()] == '2':
				msg(groupchat, u'/me видит почётного флудераста - ' + nick)
				return
			if data[(get_true_jid(groupchat+'/'+nick)).lower()] == '1':
				reply('public', [groupchat+'/'+nick, groupchat, nick], u'Again, we will flood or?')
				return


		DBPATH='Bot-Tools/'+groupchat+'/greetex.txt'
		if check_file(groupchat,'greetex.txt'):
			GREETEX = eval(read_file(DBPATH))
			if aff in GREETEX.keys():
				mas = GREETEX[aff]
				res = random.choice(mas)

				res_ = string.split(res, ' ', res.count(' '))



				while y != len(res_):
#					if '%NICK%' == res_[y]:
					if res_[y].count('%NICK%')>0:
						if res_[y].count(',')>0:
							res_[y] = nick+','
						if res_[y].count('.')>0:
							res_[y] = nick+'.'
						if res_[y].count('!')>0:
							res_[y] = nick+'!'
						if res_[y].count('?')>0:
							res_[y] = nick+'?'
						if (res_[y].count(',')==0) & (res_[y].count('.')==0) & (res_[y].count('!')==0) & (res_[y].count('?')==0):
							res_[y] = nick
					version[0] = '[empty]'
					version[1] = '[empty]'
					version[2] = '[empty]'
					if ( res.count('%VER_NAME%')>0 ) | ( res.count('%VER_VER%')>0 ) | ( res.count('%VER_OS%')>0 ):
						handler_version_ex('public', [groupchat+'/'+nick, groupchat, nick], '')
						time.sleep(6.0)

					if res_[y].count('%VER_NAME%')>0:
						if res_[y].count(',')>0:
							res_[y] = version[0]+','
						if res_[y].count('.')>0:
							res_[y] = version[0]+'.'
						if res_[y].count('!')>0:
							res_[y] = version[0]+'!'
						if res_[y].count('?')>0:
							res_[y] = version[0]+'?'
						if (res_[y].count(',')==0) & (res_[y].count('.')==0) & (res_[y].count('!')==0) & (res_[y].count('?')==0):
							res_[y] = version[0]


					if res_[y].count('%VER_VER%')>0:
						if res_[y].count(',')>0:
							res_[y] = version[1]+','
						if res_[y].count('.')>0:
							res_[y] = version[1]+'.'
						if res_[y].count('!')>0:
							res_[y] = version[1]+'!'
						if res_[y].count('?')>0:
							res_[y] = version[1]+'?'
						if (res_[y].count(',')==0) & (res_[y].count('.')==0) & (res_[y].count('!')==0) & (res_[y].count('?')==0):
							res_[y] = version[1]


					if res_[y].count('%VER_OS%')>0:
						if res_[y].count(',')>0:
							res_[y] = version[2]+','
						if res_[y].count('.')>0:
							res_[y] = version[2]+'.'
						if res_[y].count('!')>0:
							res_[y] = version[2]+'!'
						if res_[y].count('?')>0:
							res_[y] = version[2]+'?'
						if (res_[y].count(',')==0) & (res_[y].count('.')==0) & (res_[y].count('!')==0) & (res_[y].count('?')==0):
							res_[y] = version[2]

					res_1 = res_1 + res_[y]
					res_1 = res_1 + ' '
					y = y + 1
					
				msg(groupchat, res_1)

#			if groupchat in GREETEX.keys():
#	 			if aff in GREETEX[groupchat]:




def handler_greetex(type,source,parameters):
	if not parameters:
		reply(type, source, u'hmmm? مثال: <ترحيب owner=اهلا %NICK% وسهلا>')
		return

	if parameters.count('=')==0:
#		msg('stalker@conference.jabber.ru', u'Отладка: '+affi+u' '+str(answ)+u' '+source[1])
		answ=greetex_work(parameters, gch=source[1])
		if answ:
			reply(type, source, u'تم')
			return
		else:
			reply(type, source, u'من هو؟')
			return

	parameters=parameters.strip()
	rawgreet = string.split(parameters, '=', 1)
	if not len(rawgreet)==2:
		reply(type, source, u'ما هذا؟')
		return
	greet=rawgreet[1].strip()
	affi=rawgreet[0].strip()
	if (affi != 'none') & (affi != 'member') & (affi != 'admin') & (affi != 'owner') & (affi != 'اظهار') & (affi != 'مسح'):
		msg(source[1], u'هل يوجد هناك مثل "'+affi+u'" :-O انا لا اعرف عن هذا =(')
		return
	if (affi == 'اظهار') | (affi == 'مسح'):
		greetex_work_2(affi, greet, source[1])
		return

	answ=greetex_work(affi, greet, source[1])
	if answ:
		reply(type, source, u'تمت الاضافه '+affi)
	else:
		reply(type, source, u'انا لا اعرف :-|')

	if not greet:
		answ=greetex_work(affi, gch=source[1])
		if answ:
			reply(type, source, u'تم')
			return
		else:
			reply(type, source, u'من هو؟')
			return

####
def greetz_work(jid='',greet='',gch=''):
	DBPATH='Bot-Tools/'+gch+'/greetz.txt'
	if check_file(gch,'greetz.txt'):
		greetzdb = eval(read_file(DBPATH))
		if jid and greet:
			if not jid in greetzdb.keys():
				greetzdb[jid]=jid
				greetzdb[jid]=greet
				write_file(DBPATH, str(greetzdb))
				return 1
			else:
				greetzdb[jid]=greet
				write_file(DBPATH, str(greetzdb))
				return 1
		elif jid:
			if jid in greetzdb.keys():
				del greetzdb[jid]
				write_file(DBPATH, str(greetzdb))
				return 1
			return 0
		else:
			return 0


def handler_greet(type,source,parameters):
	if not parameters:
		reply(type, source, u'و؟')
		return
	parameters=parameters.strip()
	rawgreet = string.split(parameters, '=', 1)
	if not len(rawgreet)==2:
		reply(type, source, u'ما كان؟')
		return
	greet=rawgreet[1].strip()
	nicks=GROUPCHATS[source[1]].keys()
	if rawgreet[0].count('@')>0 and rawgreet[0].count('.')>0:
		jid=rawgreet[0]
	elif rawgreet[0] in nicks:
		jid=get_true_jid(source[1]+'/'+rawgreet[0])
	else:
		reply(type, source, u'اهو هنا؟ :-O')
		return
	if not greet:
		answ=greetz_work(jid,gch=source[1])
		if answ:
			reply(type, source, u'تم')
			get_greetz(gch=source[1])
			return
		else:
			reply(type, source, u'من هو')
			return
	answ=greetz_work(jid,greet,source[1])
	if answ:
		reply(type, source, u'aga')
		get_greetz(gch=source[1])
	else:
		reply(type, source, u'ماهو؟')
		
			
def atjoin_greetz(groupchat, nick, aff, role):
	if time.time()-INFO['start']>10:	
	 jid=get_true_jid(groupchat+'/'+nick)
	 if groupchat in GREETZ.keys():
	 	if jid in GREETZ[groupchat]:
	 		msg(groupchat, nick+'> '+GREETZ[groupchat][jid])
	 		
	 		
def get_greetz(gch):
	grtfile='Bot-Tools/'+gch+'/greetz.txt'
	try:
		grt = eval(read_file(grtfile))
		GREETZ[gch]=grt
	except:
		pass
			
###طرد و فصل
aff_pending=[]
def handler_aff(typ, source, parameters):
	aff_list={u"moder":{'role':'moderator'},u"member": {'affiliation':'member'},u"participant":{'role':'participant'},u"outcast": {'affiliation':'outcast'},u'owner':{'affiliation':'owner'},u'admin':{'affiliation':'admin'}}
	

	if not aff_list.has_key(parameters):
		reply(typ, source, u"اسف . انا لا اعرف هذه الكلمه")
		return

	groupchat=source[1]
	id = 'a'+str(random.randrange(1, 1000))
	globals()['aff_pending'].append(id)
	iq=xmpp.Iq('get',to=groupchat,queryNS=xmpp.NS_MUC_ADMIN,xmlns=None)
	iq.getQueryChildren().append(xmpp.Protocol('item',attrs=aff_list[parameters]))
	iq.setID(id)
	param=''
	JCON.SendAndCallForResponse(iq, handler_aff_answ,{'mtype': typ, 'source': source, 'param': param})
	return

def handler_aff_answ(coze, res, mtype, source, param):
	id = res.getID()
	if id in globals()['aff_pending']:
		globals()['aff_pending'].remove(id)
	else:
		print 'someone is doing wrong...'
		return
	if res:
		if res.getType() == 'result':
		#-=
			aa=res.getTag("query")
                        if aa==None:
                                rep=u"fatal error, unable to query"
                        else:
                                m=aa.getTags("item")
                                if len(m)==0:
                                        rep=u"empty"
                                else:
                                        rep=""
                                        for t in m:
                                                ats=t.getAttrs()
                                                if ats.has_key("jid"):
                                                        rep+=t["jid"]+" "
                                                if ats.has_key("affiliation"):
                                                        rep+=t["affiliation"]+" "
                                                if ats.has_key("role"):
                                                        rep+=t["role"]+" "
                                                reas=t.getTag("reason")
                                                if reas!= None:
                                                        dt=reas.getData()
                                                        if dt!=None:
                                                                rep+=dt+" "
                                                rep+="\n"
		#-=
		else:
			rep = u'لا استطيع'
	if mtype=="public":
		reply(mtype, source, u"تم الارسال الى الخاص")
	reply("private", source, rep)
	

def handler_bot_nick(type, source, parameters):
	if not parameters:
		reply(type, source, u'*TEASE*')
		return
	else:
		add_gch(source[1], parameters)
		join_groupchat(source[1], parameters)
	reply(type, source, u'الان انا لدى اسم جديد ;-)')

def handler_admin(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'تدفع كام؟ :-D')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				jid = get_true_jid(groupchat+'/'+nick)
				order_admin(groupchat, jid, u'تم . اصبح الان مدير')
				return

def handler_owner(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'*TEASE*')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				jid = get_true_jid(groupchat+'/'+nick)
				order_owner(groupchat, jid, u'تم . اصبح الان اونر')
				return

def handler_unban(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'*TEASE*')
		return
	else:
		jid = parameters
		order_unban(groupchat, jid)
		reply(type, source, u'تم . هذا الايميل مفصول الان')
		return

def handler_admin(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'*TEASE*')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				jid = get_true_jid(groupchat+'/'+nick)
				order_admin(groupchat, jid, u'تم . اصبح الان ادمن')
				return
				
def handler_ban(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'*TEASE*')
		return
	else:
		if not parameters.count('@'):
			nick = parameters
			if GROUPCHATS.has_key(source[1]):
				if not nick in GROUPCHATS[groupchat]:
					reply(type, source, u'من؟')
					return
				else:
					jid = get_true_jid(groupchat+'/'+nick)
					order_banjid(groupchat, jid, u'باى باى ;-)')
					reply(type, source, u'تم . اصبح الان فى قائمه الفصل')
					return
		else:
			jid = parameters
			order_banjid(groupchat, jid, u'*TEASE*')
			reply(type, source, u'تم . اصبح الان فى قائمه الفصل')
			return

def handler_ban_nick(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'تدفع كام؟ :-D')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				jid = get_true_jid(groupchat+'/'+nick)
				order_banjid(groupchat, jid, u'*TEASE*')
				reply(type, source, u'تم . الان هذا الاسم مفصول)')
				return
		
def handler_ban_jid(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u':-D')
		return
	else:
	        if not parameters.count(' '):
			jid = parameters
			order_banjid(groupchat, jid, u'*TEASE*')
			reply(type, source, u'تم . هذا الايميل مفصول الان')
			return
		else:
			parameters = parameters.split()
			jid = parameters[0]
			order_banjid(groupchat, jid, parameters[1])
			reply(type, source, u'تم . اصبح الان فى قائمه الفصل')
			return
			
def handler_visitor(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'من؟')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				
				order_visitor(groupchat, nick, u'Shut up ;-)')
				reply(type, source, u'تم سحب حق التحدث')
				return

def handler_participant(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'ماذا؟')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				
				order_participant(groupchat, nick, u'اهلا @}->--')
				reply(type, source, u' تم اصبح الان مشارك')
				return

def handler_kick(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'ماذا؟')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				
				order_kick(groupchat, nick, u'تم طردك')
				reply(type, source, u'تم طرده')
				return

def handler_member(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'ماذا؟')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
				jid = get_true_jid(groupchat+'/'+nick)
				order_member(groupchat, jid, u'اهلا ;-)')
				reply(type, source, u'تم اصبح الان عضو')
				return

def handler_moderator(type, source, parameters):
	groupchat = source[1]
	if not parameters:
		reply(type, source, u'ماذا؟')
		return
	else:
		nick = parameters
		if GROUPCHATS.has_key(source[1]):
			if not nick in GROUPCHATS[groupchat]:
				reply(type, source, u'من؟')
				return
			else:
			
				order_moderator(groupchat, nick, u'احلا مدير')
				reply(type, source, u' تم اصبح الان مدير مؤقت')
				return


def handler_where(type, source, parameters):

	cnt = 0
	gch = ''
	gch_cnt = []
	for gch in GROUPCHATS.keys():
		for nicks in GROUPCHATS[gch]:
			
				cnt += 1
		gch_cnt.append((gch, cnt))
		cnt = 0
	n = 1
	msg = u'انا موجود في هذه الرومات: '+str(len(gch_cnt))+'\n'
	for i in gch_cnt:
		msg += str(n)+'. '+i[0]+' ['+str(i[1])+']\n'
		n += 1
	reply(type, source, msg)
	

def handler_ban_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_banjid(gch, jid, u'تم الفصل من جميع الرومات')
	     
def handler_kick_everywhere(type, source, nick):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_kick(gch, nick, u'تم الطرد من جميع الرومات')

def handler_unban_everywhere(type, source, jid):
	gch=source[1]
	for gch in GROUPCHATS.keys():
	    order_unban(gch, jid)
	  
def order_admin(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'admin'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_owner(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'owner'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_kick(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	kick=query.addChild('item', {'nick':nick, 'role':'none'})
	kick.setTagData('reason', get_bot_nick(groupchat)+': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_unban(groupchat, jid):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	query.addChild('item', {'jid':jid, 'affiliation':'none'})
	iq.addChild(node=query)
	JCON.send(iq)

def order_participant(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	visitor=query.addChild('item', {'nick':nick, 'role':'participant'})
	visitor.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_ban(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'nick':nick, 'affiliation':'outcast'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_banjid(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('ban'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'outcast'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_member(groupchat, jid, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	ban=query.addChild('item', {'jid':jid, 'affiliation':'member'})
	ban.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_moderator(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	visitor=query.addChild('item', {'nick':nick, 'role':'moderator'})
	visitor.setTagData('reason', get_bot_nick(groupchat)+u': '+reason)
	iq.addChild(node=query)
	JCON.send(iq)

def order_unmember(groupchat, jid):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID(str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	query.addChild('item', {'jid':jid, 'affiliation':"none"})
	iq.addChild(node=query)
	JCON.send(iq)
####شعور و مستقبل
def handler_vortex_1(type, source, parameters):
	replies = [u'الحب',u'الارهاق',u'التعب',u'الاقياء',u'الغثيان',u'وجع في الموخرة',u'حب رجل',u'حب فتاة',u'تخورف من دفع المصاري',u'الاحباط',u'الكراهية',u'فعل المستحيل',\
u'الغباء',u'دووخة',u'انه كلب',u'انه حمار',u'بانه ملك',u'بانه خاروف للصبايا',u'الندم',u'بانه يحب صديقه وسيتجوز منه',u'بانه سيتمرد على اونرات الروم لذالك يفضل تقليعه',u'بانه في زورق بلبحر مع اربع نساء',u'باختلال عقلي',u'الم في الفص الايسر من المخ',u'انه علي وشك ان يبظ ولد',u'الحاجه الى تناول الشعيبيات',u'بأنه الاذكى بين الجميع',\
u'المشيخة',u'انه حمار متنقل',u'انه اجمل شخص هنا',u'انه اقوى رجل في العالم',u'انه ولد عاق',u'انه لا يساوي فرنك مصدي',u'انه من اصل ادلبي',u'انه حنان :lol:',u'الاسهال',u'انه سيموت بعد ساعه',u'الاسترخاء',u'انه خلق من اجل الافتراس',u'انه توتو',u'انه مااااااااع',u'انه سيتبوثر في الغد',\
u'المراهقة',u'انه فساد كلب',u'انه نصاب',u'انه متعالي فوق الجميع وهو في الواقع حشرة صدقني¡¡',u'انه سوبر مان',u'الاختلال العقلي',u'فعل المنكر',u'انه لا يشعر بشيء زي الكر',u'انه منحط',u'انه حقير',u'انه بائس',u'انه اخرق ولا حاجه لعيشته بعد الآن',u'انه غبي وطلطميس وبلهموطي',u'النفاق وانه دجال منحط',u'انه سوبر مان ايشطلاه',u'الراحة والاستقلالية',u'انه اسير الاحزان',u'الفروسية',u'قمرجي كلب',u'انه نصف حيوان ونص انسان',u'انه في جسد انسان ولكن العقل حمار',u'الحب العميق',u'الرومنسيةة واه يحنان',u'العششششششق',u'انه احلا شخص هنا',u'انه ادمن على المخدرات']
	balas = random.choice(replies)
	if type == 'public':
		if source[1]:
			reply(type, source, balas)
	elif type == 'private':
		reply(type, source, balas)

def handler_vortex_2(type, source, parameters):
	replies = [u'بياع غاز :-[', u'ضابط',u'دكتور داخلية',u'لوووووواء',u'جماعة نحنا الدولة ولاك',u'رئيس عصابة',u'ملحد والعياذ بلله', u'زبااااال',u'هكرجي8-(', u'جليس اطفال',u'راعي اغنام',u'تاجر مخدرات',u':-] لا مستقبل لك',u'كيميائي عظيم',u'رقاصةة :lol: ',u'سكافي',u'خاروف نسوان',u'مليونير',u'بياع بلاستيك',u'نجاار باطون',u'وزير كهرباء',u'كشاش حمام',u'بياع سكاكين',\
u'حرامي مصاري',u'تمديد مجارير',u'كوافير نسائي',u'مصلح تلفزيونات وقراقعين',u'شيخ فتنة',u'ممثل',u' محامي نصاب',u'مهندس معماري',u'بياع شاورما',u'ادمن سيرف'u'بياع عرانيس علكورنيش',u'دكتور نسائية',u'لص وحرامي',u'الوكيل الرسمي لشركة ايفون',\
u'تقليد صوت الحمار',u'حلب ابقار واغنام',u'تركيب ستلايتات',u'بياع خضرا',u'تصليح جوالات ',u'سرقة نحاس من عواميد الكهربا تبع الدولة',u'تزحيط الناس',u'تعديل نسخ',u'عارض ازياء',u'فلاح',u'ما الو مستقبل ولووووو',u'مصارع سومو',\
u'تصنيع صابون ومنظفات',u'دكتور اسنان',u'اعور دجاااااال',u'ملك جمال',u'طبيب عيون',u'تقليد صوت الكلب',u'شفط جور فنية من غير تكسير البلاط',u'طنبرجي يا خال',u'تعفيشش برادات وغسالات',u'لاعب شطرنج عالمي',u'صاحب كازية',u'مهربجي اثار',\
u'صاحب بنك',u'تاجر سيارات',u'شرطي مرور',u'بيع بيدونات موي',u'مهندس ديكور',u'فوتو غرافي محترف',u'شهيد بأذن الله',u'تعليم ابتدائي',u'سيدفن ابنته وهي حية',u'سيصاب بلطفح الجلدي'u'ارمل',u'مطلق',u'سيفهم لغة الكلاب',u'النوم في قن الجاج',u'سيحصل على شهادة حيونة',\
u'مصمم مواقع زرقاء',u'كلب حراسة',u'باديكارت نسواني',u'صيدلاني',u'سيصاب بمرض النقرس',u'تنظيف تواليتات',u'سيموت قبل ان يتزوج',u'تطهير ولاد',u'طبيب بيطري',u'سيتزوج بنت ترامب',u'محلل سياسي',u'تحليل السكر في البول',u'عالم فيزيالوجي',u'مهندس ديكور',u'أمن جنائي',\
u'عقيم',u'جرسون في كافيه'u'سيفارق الحياة عما قريب',u'العمل في محل حلويات',u'منجم لعين',u'سيتحور جنسيا(ملاحظة صغيرة التحور : اي يصبح فتاه اذا كان شاب والعكس اذا كان شاب)',u'تربية ماشيةة',u'الرؤية خلال الظلام',u'سيحرق حيا',\
u'التزوج من أمرآة عقيمة',u'سيصبح مختل عقليا',u'سيعدم امام مكب زبالة',u'سيفتح دكان سمانة',u'الاصابة بمرض التبول وهو نائم',u'سيموت شنقا',u'تصنيع احذية اوروبية',u'سيعمل في محل البسة',u'سيصاب بلزهايمار',u'الالتحاق بجبهة النصرة',u'التحول الى شارلو بعد منتصف الليل',u'سيصاب بسكتة قلبية',u'التحول الى انثى',u'في الجيش الألكتروني',\
u'النباح لساعات متواصلة',u'دكتور بولية',u'سيصاب بجلطة دماغية',u'سكرجي وشرب حب وحشيش'u'موجه مدرسة',u'سيفلح عليه ذي الكلب في الدريج',u'السقوط في الحمم البركانية',u'سيصاب بلصمات',u'سيطالع هواء في سرفيس ركاب ويسمعه الناس وياكل خجلة بدا الله',u'التنفس تحت الماء',u'الاصابة بمرض الخوف حيث عندما يخاف سيعملها تحته من شدة الفزع',u'الاصابة بلديدان المعوية',u'كاتب قصص تاريخية',\
u'التزوج بأمرة روسية',u'سيصاب بشلل رباعي',u'التمثيل في فيلم SAW',u'سيمزق اربا من قبل اسماك القرش',u'استاذ رياضة',u'سباح عالمي',u'العمل في مكتب عقاري',u'سيدرس في جامعة نيو يورك',u'تمديد صحيةة',u'التزوج من امرأه تزيده ثلاثة اضعاف وزنه (بلمشرمحي بقرة)',u'ضابط طيار',u'ضابط مهندس',u'مهرج في سيرك',u'معمرجي بلوك',u'مبلط',u'سيعمل في المفاعلات النووية',u'سائق دبابة',\
u'مطلوب من الانتربول الدولي',u'السفر للفضاء',u'سيصبح رجل حقيقي',u'سيخونه حبيبه',u'لاعب في برشلونة',u'لاعب في ريال مدريد',u'التحول لكتلة كع بعد الثانية عشر ليلا',u'مصمم مواقع',u'معاون جراح',u'سيعمل في صالون حلاقة',u'سيرزقه الله طفل منغولي',u'ممثل في الدراما السورية',u'طاهي عالمي'u'الفشل في كل شيء',u'سيأكل قتلة في الشارع تلت ارباعها موت قدام حبيبه',u'الأصابة بلكساح والتشلفط والخزع',u'سيصبح ادلبي الطباع',u'سيضطر لأكل لحم كلب',\
u'سيصاب بلعمى والبكم',u'التغوط في فم صديقه المقرب',u'سيزخف له دنب',u'ستبتر اطرافه',u'التحول الى مستكلب عند اكتمال القمر',u'فقدان الذاكرة',\
u'الاختفاء متى يريد',u'ثروته ستقدر بترليونات الدولارات',u'اذكى من نيوتن واينشتاين',u'الأصابة بمتلازمة دوان',u'سيخاوي الجان',u'الفشل في جامعته',u'سيمردغه ضابطه في الجاموقة',u'الاعفاإء من عسكريته',u'سيبقى شابا طول الحياة',\
u'سيكتشف كوكب جديد',u'سيصبح اجرودي',u'تناول الفئران والبزيقات على العشاء يوميا',u'سيحترق في وجهه بلزيت في درجه غليانه',u'سيأكل قتلة نصها موت في شارع الزراعة',u'سيغضب عليه دنيا واخرة من قبل ولديه',u'الرقص في كبريه',u'السفر الى سنغافورا',u'مفتي جمهورية',u'اكتشاف سائل يخفي الانسان',u'تنظيف حظيرة الحيوانات',u'سيغدر بأعز اصدقائه',u'قاضي نصاب',u'قندرجي',u'سرقة بنك عودة',\
u'سيموت وحيدا !!',u'رئيس جمهورية',u'لاعب كونفو',u'التزوج اربع مرات',u'سيرزق بطفل انبوب',u'السكن في موريتانيا',u'الانشقاق مع داعش',u'صانع عطورات',u'سيخون زوجته',u'ستفصل نسخته من هذه الروم',u'ستسممه زوجته'u'تمسيح جوخ للرايح ولجاي',u'التطوع في الهلال الأحمر',\
u'سيفهم لغة الحمار',u'سبيع ابنه مقابل الفلوس',u'راقص باليه',u'سيصبح اطول شخص في العالم',u'سيصبح اقصر شخص في العالم بمعنى قزم',u'سيتم لعنه كلما هز الكلب دنبه',u'حمار متنقل',u'العمل في حواش لبندورة ولبتنجين ولحفر وهيك',u'سيتزوج من شاب',u'سيرى الكون على حقيقته!!',u'اختراع سلاح كيميائي فتاك',\
u'سيصبح لون بشرته اسود من كيس الزبالة',u'جلي صحون في المطعم',u'سرلنكيةة',u'سرقة مصرف عقاري',u'اذكى شخص على الكوكب',u'الموت المفاجئ في عرسه',u'باحث في علم النفس',u'سيتم سحبه للاحتياط',u'سيبزق في وجهه اربعه اشخاص مقربين',u'سيحول الفضة الى ذهب',u'اكتشاف اخر عنصر في الكيمياء',\
u'سيطبق انثى ثلاثة شهور على السيريا وبلأخر سيكتشف انها صديقه وسيهدده بلصور',u'سينتحر من ناطحه سحاب',u'امتلاك منزل في دبي',u'تمديد كهربا',u'فقدان السمع',u'ستبلعه افعى كبيرة',\
u'سيحترق منزله',u'الاستحمام بزيت اونا مغلي'u'الغرق في جاموقة',u'سيصاب بلتوحد',u'سيحرق ب النيتروجين السائل',u'سيصبح اصلع واحلس اي اجرودي',u'تركيب قصاطر بولية',u'سيصاب بمرض الفرحة',\
u'سيقوم بعمل تنفس طبيعي للحمار',u'امتلاك جزيرة لوحده',u'اغنى شخص في العالم',u'ستضربه زوجته بكندرة كعب عالي',u'ستستقر رصاصة في جمجمته',u'اعظم رسام',u'احتساء الشعير والبعير على العشاء',u'فيلسوف',u'بياع جبس وبطاطا',u'امتلاك منزل في الرمال الذهبية',\
u'سيقتل جميع افراد عائلته',u'دكتور في جامعة تشرين',u'سيقوم بعملية فتاق',u'مقدم',u'عميد',u'سيقع في بئر بعمق 4000 km',u'الأصابة بجنون البقر',u'توصيل طلبات بيتزا'u'كر كبير',\
u'سيتغوط في فهمه فرس نهر',u'سيصاب بلطفح الجلدي',u'الموت من البرق',u'تغسيل سيارات',u'التحول الى قرد'u'ستنشق الأرض وتبلعه',u'معيد في الجامعة',u'مراهق كلب',u'سيعمل في صالون لتجميل السيدات وازالة الشعر',u'اختراع سيارة تعمل على الماء',u'سيفتن بنغل',u'سيصبح كركدن',u'الصعود ل اعلى قمة في العالم',u'الموت في عاصفة ثلجية',\
u'قافز مظلات ولكن سيقفز من الطائرة ويصطدم بحجرة كبيرة وسيتخوزق',u'سيقع في متاهة صحراوية ويعطش ويضطر لشرب بوله ليبقى على قيد الحياة',u'داسوس ل أمريكا',u'معالج فيزيائي',u'سيخون وطنه',u'سيصبح احد عجائب الدنيا السبع',u'سيختنق في جو من ثاني اوكسيد الكربون والفوسفاجين',u'سينقع وجهه في حمض الكبريت المركز',\
u'سيصاحب بأخطر الحروق في وجهه',u'سيلتهمه تمساح',u'اكتشاف سر السحر الأسود',u'التفنيص قدام البنات',u'سيخرق قانون الجاذبية الأرضية',u'العيش وحيدا طوال حياته',u'شحاد',u'مصلحجي كلب',\
u'اقبح شخص في الكوكب',u'اجمل شخص في الكوكب',u'عالم فلك'u'صنع قنبلة ذرية',u'فرخ نوري',u'اكتشاف سر الفضائيين',u'السفر للعام 2099 ',u'المشي فوق سطح الماء',u'سيقتل ثلث سكان الكوكب',\
u'تمسيح وتلميع بواط',u'ستتهكر صفحته على الفيس بوك',u'نبير زيتون وجوز',u'ربح الجائزة الكبرى في اليانصيب',u'سيصاب برصاصة خطاط في عيد رأس السنة',u'عضو في مجلس الشعب',u'ستسكنه روح شريرة',u'مهندس بتروكيميائي',u'سيبلع قطعه صغيرة من الراديوم المشع',\
u'معرفة سر الزئبق الأحمر الذي حير الملايين حتى وقنا هذا',u'سيدخل في غيبوبة لمدة عشرين عام',u'التهرب من واقعه',u'مخرطجي كلب حيث عندم يتحدث تحس انها تمطر مع برق ورعد وعواصف من شدة الكذب',u'امتلاك منزل الكتروني',u'النوم مع ميت في نفس القبر',u'سيضرط فص عندما يكون يخطب حبيبته ويسمعه ابوها ويمسح بكرامته الأرض',u'عميل مزدوج',\
u'سيكون على طريق سفر طويل وسيقضي حاجته في ثيابه',u'سيكبر عليه ثلاث مرات من احد افراد داعش',u'أمين صندوق',u'مندوب مبيعات',u'الأصابة بوباء الطاعون',\
u'الأصابة بفايروس نقص المناعة المكتسب',u'مالك الفيس بوك',u'الحصول على جائزة نوبل في الفيزياء',u'سيدخل اسمه في موسوعه غينس للأرقام القياسية',u'امتلاك اربعة اطنان من الماس']
	balas = random.choice(replies)
	if type == 'public':
		if source[1]:
			reply(type, source, balas)
	elif type == 'private':
		reply(type, source, balas)
		
		
# Love
def handler_love(type, source, body):		
	reply(type, source, u"نسبة الحب\n %s بالمئة"% (random.randrange(0,99)))

#Heat
def handler_heat(type, source, body):		
	reply(type, source, u"نسبة الكره\n%s بالمئة"% (random.randrange(0,99)))
####بوس و علوطة و طبقلي
def handler_kiss(type, source, parameters):
	if type=='private':
		reply(type,source,u'هذا الامر متاح في الرومات فقط')
		return
	groupchat = source[1]
	if parameters:
		if parameters==u'last10':
			cnt=0
			rep=''
			nicks = set()
			for x in [poke_nicks[source[1]] for x in poke_nicks]:
				nicks = nicks | set(x)
			for x in nicks:
				cnt=cnt+1
				rep += str(cnt)+u') '+x+u'\n'
			reply('private',source,rep[:-1])
			return
		if not poke_nicks.has_key(source[1]):
			poke_nicks[source[1]]=source[1]
			poke_nicks[source[1]]=[]
		if len(poke_nicks[source[1]])==10:
			poke_nicks[source[1]]=[]
		else:
			poke_nicks[source[1]].append(source[2])
		if not parameters == get_bot_nick(source[1]):
			if parameters in GROUPCHATS[source[1]]:
				pokes=[]
				pokes.extend(poke_work(source[1]))
				pokes.extend(eval(read_file('static/kiss.txt'))['kiss'])
				rep = random.choice(pokes)
				msg(source[1] ,u'\n '+rep % parameters)
			else:
				reply(type, source, u'هو فين ده؟ :-O')
		
def handler_hug(type, source, parameters):
	if type=='private':
		reply(type,source,u'هذا الامر متاح في الرومات فقط')
		return
	groupchat = source[1]
	if parameters:
		if parameters==u'last10':
			cnt=0
			rep=''
			nicks = set()
			for x in [poke_nicks[source[1]] for x in poke_nicks]:
				nicks = nicks | set(x)
			for x in nicks:
				cnt=cnt+1
				rep += str(cnt)+u') '+x+u'\n'
			reply('private',source,rep[:-1])
			return
		if not poke_nicks.has_key(source[1]):
			poke_nicks[source[1]]=source[1]
			poke_nicks[source[1]]=[]
		if len(poke_nicks[source[1]])==10:
			poke_nicks[source[1]]=[]
		else:
			poke_nicks[source[1]].append(source[2])
		if not parameters == get_bot_nick(source[1]):
			if parameters in GROUPCHATS[source[1]]:
				pokes=[]
				pokes.extend(poke_work(source[1]))
				pokes.extend(eval(read_file('static/hug.txt'))['hug'])
				rep = random.choice(pokes)
				msg(source[1] ,u'\n '+rep % parameters)
			else:
				reply(type, source, u'هو فين ده؟ :-O')		

def handler_love(type, source, parameters):
	if type=='private':
		reply(type,source,u'هذا الامر متاح في الرومات فقط')
		return
	groupchat = source[1]
	if parameters:
		if parameters==u'last10':
			cnt=0
			rep=''
			nicks = set()
			for x in [poke_nicks[source[1]] for x in poke_nicks]:
				nicks = nicks | set(x)
			for x in nicks:
				cnt=cnt+1
				rep += str(cnt)+u') '+x+u'\n'
			reply('private',source,rep[:-1])
			return
		if not poke_nicks.has_key(source[1]):
			poke_nicks[source[1]]=source[1]
			poke_nicks[source[1]]=[]
		if len(poke_nicks[source[1]])==10:
			poke_nicks[source[1]]=[]
		else:
			poke_nicks[source[1]].append(source[2])
		if not parameters == get_bot_nick(source[1]):
			if parameters in GROUPCHATS[source[1]]:
				pokes=[]
				pokes.extend(poke_work(source[1]))
				pokes.extend(eval(read_file('static/love.txt'))['love'])
				rep = random.choice(pokes)
				msg(source[1] ,u'\n '+rep % parameters)
			else:
				reply(type, source, u'هو فين ده؟ :-O')			
####نجاح
def handler_success(type, source, parameters):
	replies = [u'@}->-- الهروب هو السبب الوحيد في الفشل، لذا يمكنك أن تنجح طالما لم تكف عن المحاولة @}->--', u'@}->-- أن تدرك كيف تفكر هذا بداية التغير. بالإضافة إلى إن عنيك ليست سوى انعكاس لأفكارك @}->--', u'@}->-- ليس الواقع سوي إدراك، فلو أردت تغير واقع حياتك أبدأ بتغير أدراكك @}->--', u'@}->-- لا تنتظر أن تسنح لك الفرصة غير العادية، بل انتهز الفرصة العادية وأجعلها عظيمة @}->--', u'@}->-- الرجل الذي لا رأي له .. كمقبض الباب يستطيع أن يديره كل ما شاء @}->--', u'@}->-- سامح غيرك وأعلم أن لكل شخص عيوبه، فتقبل غيرك حتى يتقبلك الآخرون @}->--', u'@}->-- عندما يتحقق العدل حتى الحيوانات تلتزم بالنظام @}->--', u'@}->-- الأسف ينظر للوراء، والقلق ينظر حوله، الإيمان ينظر إلى المستقبل @}->--', u'@}->-- السعادة دائما تبدو ضئيلة عندما نحملها بإيادينا الصغيرة، لكن عندما نتعلم كيف نشارك بها سندرك كم هي كبيرة وثمينة @}->--', u'@}->-- الشتاء هو بداية الصيف، والظلام هو بداية النور، والضغوط هي بداية الراحة، والفشل هو بداية النجاح @}->--', u'@}->-- إذا كنت مع الله … فأنت مع الأغلبية المطلقة @}->--', u'@}->-- لا تعطي  لأحد الأولوية في حياتك عندما تكون أنت خيارًا ثانويًا في حياته، ولا تفعل المستحيل لمن يفعل لك الممكن @}->--', u'@}->--  @}->--', u'@}->-- ما كان يسير في دمي وعروقي، ويعيش في وجداني لابد أن يخرج للحياة @}->--', u'@}->-- لن تسطيع أن تعطي بدون الحب، ولن تستطيع أن تجب بدون تسامح @}->--', u'@}->-- إن لم يكن لك هدف، فستكون من أهداف الآخرين @}->--', u'@}->-- يقولون أن حلمي مستحيل، وأنا أقول أن الله على كل شيء قدير @}->--']
	balas = random.choice(replies)
	if type == 'public':
		if source[1]:
			reply(type, source, balas)
	elif type == 'private':
		reply(type, source, balas)
####شوق
def handler_flirt(type, source, parameters):
        flirts = [u'الشوق قاتلني .. و القلب احتار :-[ ']
        nick = random.choice(GROUPCHATS[source[1]].keys())
        flirt = random.choice(flirts)
        themsg = nick+': '+flirt
        msg(source[1], themsg)
####نكز
poke_nicks={}

def handler_poke(type, source, parameters):
	if type=='private':
		reply(type,source,u'هذا الامر متاح في الرومات فقط')
		return
	groupchat = source[1]
	if parameters:
		if parameters==u'last10':
			cnt=0
			rep=''
			nicks = set()
			for x in [poke_nicks[source[1]] for x in poke_nicks]:
				nicks = nicks | set(x)
			for x in nicks:
				cnt=cnt+1
				rep += str(cnt)+u') '+x+u'\n'
			reply('private',source,rep[:-1])
			return
		if not poke_nicks.has_key(source[1]):
			poke_nicks[source[1]]=source[1]
			poke_nicks[source[1]]=[]
		if len(poke_nicks[source[1]])==10:
			poke_nicks[source[1]]=[]
		else:
			poke_nicks[source[1]].append(source[2])
		if not parameters == get_bot_nick(source[1]):
			if parameters in GROUPCHATS[source[1]]:
				pokes=[]
				pokes.extend(poke_work(source[1]))
				pokes.extend(eval(read_file('static/delirium.txt'))['poke'])
				rep = random.choice(pokes)
				msg(source[1],u'/me '+rep % parameters)
			else:
				reply(type, source, u'هو فين ده؟ :-O')
		else:
			reply(type, source, u'ذكى, صعبه, صح؟ ]:->')	
	else:
		reply(type, source, u'انت بتحلم؟ :D')
		
def handler_poke_add(type, source, parameters):
	if not parameters:
		reply(type, source, u'وبعدين؟')
	if not parameters.count('%s'):
		reply(type, source, u'انا مش شايف %s')
		return
	res=poke_work(source[1],1,parameters)
	if res:
		reply(type, source, u'تمت الاضافه')
	else:
		reply(type, source, u'غير ظاهر')
		
def handler_poke_del(type, source, parameters):
	if not parameters:
		reply(type, source, u'و؟ :-|')
	if parameters=='*':
		parameters='0'
	else:
		try:
			int(parameters)
		except:
			reply(type,source,u'تم الغاء الامر')
	res=poke_work(source[1],2,parameters)
	if res:
		reply(type, source, u'تم المسح')
	else:
		reply(type, source, u'غير ظاهر')
		
def handler_poke_list(type, source, parameters):
	rep,res=u'',poke_work(source[1],3)
	if res:
		res=sorted(res.items(),lambda x,y: int(x[0]) - int(y[0]))
		for num,phrase in res:
			rep+=num+u') '+phrase+u'\n'
		reply(type,source,rep.strip())
	else:
		reply(type,source,u'لاتوجد عبارات مخصصه')
		
def poke_work(gch,action=None,phrase=None):
	DBPATH='Bot-Tools/'+gch+'/delirium.txt'
	if check_file(gch,'delirium.txt'):
		pokedb = eval(read_file(DBPATH))
		if action==1:
			for x in range(1, 21):
				if str(x) in pokedb.keys():
					continue
				else:
					pokedb[str(x)]=phrase
					write_file(DBPATH, str(pokedb))
					return True
			return False
		elif action==2:
			if phrase=='0':
				pokedb.clear()
				write_file(DBPATH, str(pokedb))
				return True
			else:
				try:
					del pokedb[phrase]
					write_file(DBPATH, str(pokedb))
					return True
				except:
					return False
		elif action==3:
			return pokedb
		else:
			return pokedb.values()
	else:
		return None
####مسابقة
QUIZ_FILE = 'static/questions.txt'
QUIZ_TOTAL_LINES = 29
QUIZ_TIME_LIMIT = 200 
QUIZ_IDLE_LIMIT = 3 
QUIZ_RECURSIVE_MAX = 20 
QUIZ_CURRENT_ANSWER = {} 
QUIZ_CURRENT_HINT = {} 
QUIZ_CURRENT_HINT_NEW = {} 
QUIZ_CURRENT_TIME = {} 
QUIZ_IDLENESS = {} 
QUIZ_IDLE_ANSWER = {}
QUIZ_START = {}
QUIZ_IDLE_ANSWER_FIRSR = {}
QUIZ_NOWORD = '*' 

import threading

HELP = u''

def sectomin(time):
        m = 0
        s = 0
        if time >= 60:
                m = time / 60
                
                if (m * 60) != 0:
                        s = time - (m * 60)
                else:
                        s = 0
        else:
                m = 0
                s = time
                

        return str(m)+u'min. in '+str(s)+u'sec.'


def quiz_timer(groupchat, start_time):
        global QUIZ_TIME_LIMIT
        global QUIZ_CURRENT_TIME
        
	time.sleep(QUIZ_TIME_LIMIT)
	if QUIZ_CURRENT_TIME.has_key(groupchat) and QUIZ_CURRENT_ANSWER.has_key(groupchat) and start_time == QUIZ_CURRENT_TIME[groupchat]:
		QUIZ_CURRENT_ANSWER[groupchat]
		msg(groupchat, u'(!) time out! ' + sectomin(QUIZ_TIME_LIMIT) + u' passed.\nCorrect answer: ' + QUIZ_CURRENT_ANSWER[groupchat])
		if QUIZ_IDLENESS.has_key(groupchat):
			QUIZ_IDLENESS[groupchat] += 1
		else:
			QUIZ_IDLENESS[groupchat] = 1
		if QUIZ_IDLENESS[groupchat] >= QUIZ_IDLE_LIMIT:
			msg(groupchat, 'اللعبة سوف يتم اكمالها تلقائيا في حالة التأخير' + str(QUIZ_IDLE_LIMIT) + ' اسئلة غير مجاب عنها.')
			del QUIZ_CURRENT_ANSWER[groupchat]
			quiz_list_scores(groupchat)
		else:
			quiz_ask_question(groupchat)

def quiz_new_question():
        global QUIZ_RECURSIVE_MAX
        
	line_num = random.randrange(29)
	fp = file(QUIZ_FILE)
	for n in range(line_num + 1):
		if n == line_num:
			(question, answer) = string.split(fp.readline().strip(), '|', 2)
			return (unicode(question, 'utf-8'), unicode(answer, 'utf-8'))
		else:
			fp.readline()

def quiz_ask_question(groupchat):
        global answer
        global QUIZ_CURRENT_TIME
        global question
        global QUIZ_IDLE_ANSWER
        global QUIZ_IDLE_ANSWER_FIRSR
        QUIZ_IDLE_ANSWER = {groupchat:{}}
	(question, answer) = quiz_new_question()
	QUIZ_CURRENT_ANSWER[groupchat] = answer
	QUIZ_CURRENT_HINT[groupchat] = None
	QUIZ_CURRENT_HINT_NEW[groupchat] = None
	QUIZ_CURRENT_TIME[groupchat] = time.time()
	threading.Thread(None, quiz_timer, 'gch'+str(random.randrange(0,9999)), (groupchat, QUIZ_CURRENT_TIME[groupchat])).start()
	msg(groupchat, u'\nالسؤال هو: \n' + question)

def quiz_ask_new_question(groupchat, ans):
        global QUIZ_CURRENT_TIME
        global answer
        global question
        global QUIZ_IDLE_ANSWER
        global QUIZ_IDLE_ANSWER_FIRSR
        QUIZ_IDLE_ANSWER = {groupchat:{}}
	(question, answer) = quiz_new_question()
	QUIZ_CURRENT_ANSWER[groupchat] = answer
	QUIZ_CURRENT_HINT[groupchat] = None
	QUIZ_CURRENT_HINT_NEW[groupchat] = None
	QUIZ_CURRENT_TIME[groupchat] = time.time()
	threading.Thread(None, quiz_timer, 'gch'+str(random.randrange(0,9999)), (groupchat, QUIZ_CURRENT_TIME[groupchat])).start()
	msg(groupchat, u'اجابة صحيحة : '+ans+u', تغيير السؤال: \n' + question)
	
def quiz_answer_question(groupchat, nick, answer):
        global QUIZ_IDLE_ANSWER
        global QUIZ_IDLE_ANSWER_FIRSR
        
	DBPATH='Bot-Tools/'+groupchat+'/quiz.cfg'
	if check_file(groupchat,'quiz.cfg'):
		QUIZ_SCORES = eval(read_file(DBPATH))
	jid = get_true_jid(groupchat+'/'+nick)
	jid = jid.lower()
	
	if QUIZ_CURRENT_ANSWER.has_key(groupchat):
                answer1 = QUIZ_CURRENT_ANSWER[groupchat].lower()
                answer2 = answer.lower()
                if answer1 == answer2:
                        if QUIZ_IDLE_ANSWER.has_key(groupchat):
                                if len(QUIZ_IDLE_ANSWER[groupchat]) != 0:
                                        if QUIZ_IDLE_ANSWER[groupchat].has_key(jid):
                                                if QUIZ_IDLE_ANSWER[groupchat][jid][1] == '1':
                                                        msg(groupchat, nick+u': انت اجبت بطريقة صحيحة')
                                                else:
                                                        razn = QUIZ_IDLE_ANSWER[groupchat][jid][0] - QUIZ_IDLE_ANSWER_FIRSR[groupchat]
                                                        msg(groupchat, nick+u': انت اجبت بطريقة صحيحة , متأخر بنسبة %.3 لكل ثانية' % razn)
                                        else:
                                                QUIZ_IDLE_ANSWER[groupchat][jid] = [time.time(), '0']
                                                
                                                razn = QUIZ_IDLE_ANSWER[groupchat][jid][0] - QUIZ_IDLE_ANSWER_FIRSR[groupchat]
                                                msg(groupchat, nick+u': انت اجبت على نحو صحيح, ولكن متـأخر بنسبة %.3 لكل ثانية' % razn)
                                        return

			if QUIZ_IDLENESS.has_key(groupchat):
				del QUIZ_IDLENESS[groupchat]
			answer_time = int(time.time() - QUIZ_CURRENT_TIME[groupchat])
			try:
                                if MODE == 'M1':
                                        alen = len(QUIZ_CURRENT_HINT_NEW[groupchat])
                                        blen = QUIZ_CURRENT_HINT_NEW[groupchat].count('')
                                        a = alen - blen
                                if MODE == 'M2':
                                        a = 0
                                        a = a + QUIZ_CURRENT_HINT[groupchat]
                        except:
                                a = 1
                        if PTS == 'P1':
                                points = QUIZ_TIME_LIMIT / answer_time / 3 + 1 / a
                        if PTS == 'P2':
                                try:
                                        alen = len(QUIZ_CURRENT_HINT_NEW[groupchat])
                                        blen = QUIZ_CURRENT_HINT_NEW[groupchat].count('')
                                        a = alen - blen
                                        procent = a * 100 / alen
                                except:
                                        procent = 10
                                
                                points = (QUIZ_TIME_LIMIT / answer_time) / (procent / 10)

			if points == 0:
                                pts = '0'
                        else:
                                pts = '+'+str(points)
			msg(groupchat, u'(!) ' + nick + u', الف مبرووووك انت حصلت على ' + pts + u' نقطة في حسابك \n الاجابة الصحيحة هي : ' + answer)			
			if not QUIZ_SCORES.has_key(groupchat):
				QUIZ_SCORES[groupchat] = {}
			if QUIZ_SCORES[groupchat].has_key(jid):
				QUIZ_SCORES[groupchat][jid][0] += points
				QUIZ_SCORES[groupchat][jid][1] += points
				QUIZ_SCORES[groupchat][jid][2] = nick
				QUIZ_SCORES[groupchat][jid][3] += 1
			else:
				QUIZ_SCORES[groupchat][jid] = [points, points, nick, 1]
			
#			quiz_list_scores(groupchat)


                        QUIZ_IDLE_ANSWER[groupchat][jid] = [time.time(), '1']
                        QUIZ_IDLE_ANSWER_FIRSR[groupchat] = time.time()

                        if QUIZ_IDLE_ANSWER.has_key(groupchat):
                                if len(QUIZ_IDLE_ANSWER[groupchat]) == 1:
                                        time.sleep(1.0)
                                        quiz_ask_question(groupchat)
	write_file(DBPATH, str(QUIZ_SCORES))

def swap(arr, i, j):
    arr[i], arr[j] = arr[j], arr[i]
 
def sort(groupchat, mas, sort=1, count=10):
        base = mas[groupchat]
        arr = []
        str1 = ''
        for a in base:
                asd = base[a][sort]
                arr += [asd]
        i = len(arr)
        while i > 1:
                for j in xrange(i - 1):
                        if arr[j] < arr[j + 1]:
                                swap(arr, j, j + 1)
                i -= 1
        top10 = 1
        prim = ''
        charcount = 0

        for z in arr:                       
                for x in base:
                        nick = base[x][2]
                        if len(nick) > charcount:
                                charcount = len(nick)
                        
        for z in arr:                       
                for x in base:
                        nick = base[x][2]
                        if len(nick) < charcount:
                                nick += ' ' * (charcount - len(nick))
                        nick += ' '
                                
                        if base[x][sort] == z:
                                str1 += str(top10)+'. '+nick+' '+str(base[x][0])+'-'+str(base[x][1])+'-'+str(base[x][3])+'\n'
                                if top10 < count:
                                        top10 += 1
                                else:
                                        str1 = prim + str1
                                        return str1
        str1 = prim + str1
        return str1



def quiz_list_scores(groupchat, sort_=1, count=10):
	DBPATH='Bot-Tools/'+groupchat+'/quiz.cfg'
	if check_file(groupchat,'quiz.cfg'):
		QUIZ_SCORES = eval(read_file(DBPATH))

        if QUIZ_SCORES.has_key(groupchat):
                if QUIZ_SCORES[groupchat]:
                        if QUIZ_IDLENESS.has_key(groupchat):
                                del QUIZ_IDLENESS[groupchat]
                        if QUIZ_CURRENT_ANSWER.has_key(groupchat):
                                result = u'(*) قائمة النتائج :\n [الاسم][الحالي][الاجمالي][الاجابات]\n'
                        else:
                                result = u'(*) قائمة النتائج:\n[الاسم][السابق][الاجمالي][الاجابات]\n'
                        result = result+sort(groupchat, QUIZ_SCORES, sort_, count)

			msg(groupchat, result)

def handler_quiz_start(type, source, parameters):
	groupchat = source[1]
	DBPATH='Bot-Tools/'+groupchat+'/quiz.cfg'
	if check_file(groupchat,'quiz.cfg'):
		QUIZ_SCORES = eval(read_file(DBPATH))
        jid = get_true_jid(source[1]+'/'+source[2])
        jid = jid.lower()
	if not groupchat:
		reply(type, source, u'ليست في الخاص')
		return
	if QUIZ_CURRENT_ANSWER.has_key(groupchat):
		reply(type, source, u'هل موجود ؟ '+HELP)
		return
	
	if not QUIZ_SCORES.has_key(groupchat):
                QUIZ_SCORES[groupchat] = {}
                write_file(DBPATH, str(QUIZ_SCORES))
        if QUIZ_SCORES.has_key(groupchat):
                if QUIZ_SCORES[groupchat].has_key(jid):
                        for kjid in QUIZ_SCORES[groupchat]:
                                QUIZ_SCORES[groupchat][kjid][0] = 0
                        
                        write_file(DBPATH, str(QUIZ_SCORES))
        QUIZ_START[groupchat] = jid
        
	if QUIZ_IDLENESS.has_key(groupchat):
		del QUIZ_IDLENESS[groupchat]
#	msg(groupchat, u'[Викторина] Викторина начата! Очки обнулены.')
	quiz_ask_question(groupchat)

def handler_quiz_stop(type, source, parameters):
	groupchat = source[1]
	if QUIZ_CURRENT_ANSWER.has_key(groupchat):
		del QUIZ_CURRENT_ANSWER[groupchat]
		msg(groupchat, u'تم ايقاف اللعبة.')
		time.sleep(1.0)
		quiz_list_scores(groupchat, 0, 10)
	else:
		reply(type, source, u'ليس هناك لعبة مبدوءة')

def handler_quiz_next(type, source, parameters):
        if QUIZ_CURRENT_ANSWER.has_key(source[1]):
                jid = get_true_jid(source[1]+'/'+source[2])
                if ACC == 'A1':
                        quiz_ask_new_question(source[1], QUIZ_CURRENT_ANSWER[source[1]])
                if ACC == 'A2':
                        if (jid == QUIZ_START[source[1]]) | (user_level(source[1]+'/'+source[2], source[1]) >= 16):
                                quiz_ask_new_question(source[1], QUIZ_CURRENT_ANSWER[source[1]])
                        else:
                                reply(type, source, u'هذا الامر مسموح فقط للاعضاء, '+HELP)
        else:
                reply(type, source, u'ليس هناك لعبة مبدوءة, '+HELP)

def handler_quiz_hint(type, source, parameters):
        global ans
	groupchat = source[1]
        ans = QUIZ_CURRENT_ANSWER[groupchat]
	if QUIZ_CURRENT_ANSWER.has_key(groupchat):
		if QUIZ_IDLENESS.has_key(groupchat):
			del QUIZ_IDLENESS[groupchat]
		if QUIZ_CURRENT_HINT[groupchat] == None:
			QUIZ_CURRENT_HINT[groupchat] = 0
		if MODE == 'M1':
                        if QUIZ_CURRENT_HINT_NEW[groupchat] == None:
                                ms = ['']
                                QUIZ_CURRENT_HINT_NEW[groupchat] = []
                                for r in range(0, len(QUIZ_CURRENT_ANSWER[groupchat])):
                                        QUIZ_CURRENT_HINT_NEW[groupchat] += ms

                        ex = 1
                        while ex == 1:
                                a = random.choice(QUIZ_CURRENT_ANSWER[groupchat])
                                if not a in QUIZ_CURRENT_HINT_NEW[groupchat]:
                                        for t in range(0, len(QUIZ_CURRENT_ANSWER[groupchat])):
                                                if QUIZ_CURRENT_ANSWER[groupchat][t] == a:
                                                        QUIZ_CURRENT_HINT_NEW[groupchat][t] = a
                                                        ex = 0
                                hint = '' 
                        for hnt in QUIZ_CURRENT_HINT_NEW[groupchat]:
                                if hnt == '':
                                        hint += QUIZ_NOWORD
                                else:
                                        hint += hnt
                        if not '' in QUIZ_CURRENT_HINT_NEW[groupchat]:
                                quiz_ask_new_question(source[1], ans)
                        else:
                                msg(groupchat, u'(*) تلميح عن الاجابة : ' + hint)
                if MODE == 'M2':
                        QUIZ_CURRENT_HINT[groupchat] += 1
                        hint = QUIZ_CURRENT_ANSWER[groupchat][0:QUIZ_CURRENT_HINT[groupchat]]
                        hint += ' *' * (len(QUIZ_CURRENT_ANSWER[groupchat]) - QUIZ_CURRENT_HINT[groupchat])
                        msg(groupchat, u'(*) تلميح عن الاجابة: ' + hint)
                        if (len(QUIZ_CURRENT_ANSWER[groupchat]) - QUIZ_CURRENT_HINT[groupchat]) == 0:
                                quiz_ask_new_question(source[1], ans)
	else:
		reply(type, source, u'ليس هناك لعبة مبدوءة, '+HELP)

def handler_quiz_answer(type, source, parameters):
        global answer
        reply(type, source, answer)



def handler_quiz_scores(type, source, parameters):
	groupchat = source[1]
	
	DBPATH='Bot-Tools/'+groupchat+'/quiz.cfg'
	if check_file(groupchat,'quiz.cfg'):
		QUIZ_SCORES = eval(read_file(DBPATH))

	if QUIZ_SCORES.has_key(groupchat):
                if QUIZ_SCORES[groupchat]:
                        if QUIZ_CURRENT_ANSWER.has_key(source[1]):
                                quiz_list_scores(groupchat, 0, 10)
                        else:
                                quiz_list_scores(groupchat, 1, 10)
                else:
                        reply(type, source, u'قاعدة البيانات فارغة , '+HELP)
        else:
                reply(type, source, u'قاعدة البيانات فارغة , '+HELP)

def handler_quiz_message(type, source, body):
	groupchat = source[1]
	if groupchat and QUIZ_CURRENT_ANSWER.has_key(groupchat):
		quiz_answer_question(source[1], source[2], body.strip())

def handler_quiz_resend(type, source, body):
        global question
        groupchat = source[1]
        if QUIZ_CURRENT_ANSWER.has_key(groupchat):
                res = u'(*) السؤال الحالي: \n'+question
                reply(type, source, res)
        else:
                reply(type, source, u'ليس هناك لعبة مبدوءة , '+HELP)

def handler_quiz_help(type, source, body):
        if QUIZ_CURRENT_ANSWER.has_key(source[1]):
                stat = u'فيد التشغيل بالفعل'
        else:
                stat = u'لم تبدأ حتى الآن'
        res = u'\n مرحبا بك في لعبة المسابقة هي لعبة تعتمد على ثقافتك العامة \n \n حالة اللعبة :    '+stat+u'\n عدد الاسئلة : '+str(QUIZ_TOTAL_LINES)+u' سؤال \n \n نقدم لك اوامر اللعبة حتى تتمكن من التعامل مع اللعبة :\n اذا اردت ان تبدا اللعب فقط اكتب \n بدء-مسابقة \n \n اذا اردت ايقاف اللعبة فقط اكتب \n ايقاف-مسابقة \n \n في حالة عجزت عن الاجابة و اردت معرفة الاجابة فقط اكتب \n الاجابة \n \n في حالة استخدام امر هات الاجابة لكي تستمر في اللعب او في حالة احببت تخطي السؤال الحالي فقط اكتب \n اعادة-السؤال \n \n في حالة صعوبة السؤال و اردت المساعدة في الاجابة فقط اكتب  \n تلميح \n \n اذا اردت معرفة نتيجة اللعبة فقط اكتب \n النتيجة \n \n للعلم لاول مرة لعبة مسابقة ببوت اربك مع تحيات فريق \n syriatalk.org \n Ahmed & darsh '
        reply(type, source, res)

def handler_quiz_base_del(type, source, body):
	groupchat = source[1]
	
	DBPATH='Bot-Tools/'+groupchat+'/quiz.cfg'
	if check_file(groupchat,'quiz.cfg'):
		QUIZ_SCORES = eval(read_file(DBPATH))

	if body == '':
                if QUIZ_SCORES.has_key(source[1]):
                        del QUIZ_SCORES[source[1]]
                        reply(type, source, u'تم مسح قاعدة البيانات بنجاح')
                else:
                        reply(type, source, u'قاعدة بيانات فارغة')
        else:
                if QUIZ_SCORES.has_key(source[1]):
                        if QUIZ_SCORES[source[1]].has_key(body):
                                del QUIZ_SCORES[source[1]][body]
                                reply(type, source, u'تم مسح قاعدة البيانات بنجاح')
                        else:
                                reply(type, source, u'قاعدة بيانات فارغة')


                else:
                        reply(type, source, u'تم مسح قاعدة البيانات بنجاح')
        write_file(DBPATH, str(QUIZ_SCORES))

def handler_afools_control(type, source, parameters):
	if parameters:
		try:
			int(parameters)
		except:
			reply(type,source,u'تم الغاء الامر')
		if int(parameters)>1:
			reply(type,source,u'تم الغاء الامر')
		if parameters=="1":
			GCHCFGS[source[1]]['afools']=1
			reply(type,source,u'تم تفعيل امر المزح')
		else:
			GCHCFGS[source[1]]['afools']=0
			reply(type,source,u'تم الغاء تفعيل امر النكات')			
	else:
		if GCHCFGS[source[1]]['afools']==1:
			reply(type,source,u'تم تفعيل امر النكات')
		else:
			reply(type,source,u'تم الغاء تفعيل امر النكات')

def get_afools_state(gch):
	if not 'afools' in GCHCFGS[gch]:
		GCHCFGS[gch]['afools']=0
##سؤال
TESTIQP = {}
ORDERMODE = {}
TESTIQBDTEXT = {}
TESTIQBDTEXTWELCOME = {}
TESTIQBDTEXTNOT = {}
TESTIQBDTEXTNOTRESON = {}
TESTIQBD = {}
TESTIQTRIALS = {}
TESTIQONOFFDEF = 0

TESTIQCONF = {}
                        

def testiq_visitor(groupchat, nick):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	visitor=query.addChild('item', {'nick':nick, 'role':'visitor'})
	iq.addChild(node=query)
	JCON.send(iq)

def testiq_participant(groupchat, nick):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	visitor=query.addChild('item', {'nick':nick, 'role':'participant'})
	iq.addChild(node=query)
	JCON.send(iq)

def testiq_kick(groupchat, nick, reason):
	iq = xmpp.Iq('set')
	iq.setTo(groupchat)
	iq.setID('kick'+str(random.randrange(1000, 9999)))
	query = xmpp.Node('query')
	query.setNamespace('http://jabber.org/protocol/muc#admin')
	kick=query.addChild('item', {'nick':nick, 'role':'none'})
	kick.setTagData('reason', reason)
	iq.addChild(node=query)
	JCON.send(iq)




def testiq_join(groupchat, nick, aff, role):
        global ORDERMODE
        if aff == 'none':
                DBPATH='Bot-Tools/'+groupchat+'/testiq.txt'
                try:
                        db = eval(read_file(DBPATH))
                        
                        if not TESTIQCONF.has_key(groupchat):
                                TESTIQCONF[groupchat] = {}
                        TESTIQCONF[groupchat] = db

                except:
                        if not TESTIQCONF.has_key(groupchat):
                                TESTIQCONF[groupchat] = {}
                        TESTIQCONF[groupchat] = {'TESTIQBDTEXT': u'_اجب على السؤال التالى للحصول على حق التحدث فى الغرفة_',
                                                 'TESTIQBDTEXTWELCOME': u'الأن يمكنك التحدث فى الغرفة',
                                                 'TESTIQBDTEXTNOT': u'اجابه خاطئه :-( , محاوله: %s',
                                                 'TESTIQBDTEXTNOTRESON': u'اسف, اجابه خاطئه !',
                                                 'TESTIQBD': {u'3+4':'7',
                                                              u'3+7':u'10',
                                                              u'9-5':u'4',
                                                              u'7-3':u'4'},                                                 'TESTIQONOFF': TESTIQONOFFDEF,
                                                 'TESTIQTRIALS': 3}
                        write_file(DBPATH, str(TESTIQCONF[groupchat]))


                if not ORDERMODE.has_key(groupchat):
                        ORDERMODE[groupchat] = {}
                if not ORDERMODE[groupchat].has_key(nick):
                        ORDERMODE[groupchat][nick] = {'order':0}
                if ORDERMODE[groupchat][nick]['order'] == 1:
                        return

                if TESTIQCONF[groupchat]['TESTIQONOFF']:
                        q = random.choice(TESTIQCONF[groupchat]['TESTIQBD'].keys())
                        a = TESTIQCONF[groupchat]['TESTIQBD'][q]
                        jid = get_true_jid(groupchat+'/'+nick)
                        if not TESTIQP.has_key(groupchat):
                                TESTIQP[ groupchat ] = {}
                        TESTIQP[ groupchat ][ jid ] = {'question':q, 'answer':a, 'trials':TESTIQCONF[groupchat]['TESTIQTRIALS']}
                        testiq_visitor(groupchat, nick)
                        msg(groupchat+'/'+nick, TESTIQCONF[groupchat]['TESTIQBDTEXT']+'\n'+TESTIQP[ groupchat ][ jid ]['question'])

def testiq_deluser(groupchat, jid):
        global TESTIQP

        time.sleep(1)

        try:
                del TESTIQP[groupchat][jid]
        except:
                pass

def testiq_message(type, source, parameters):
        if type == 'private':
                groupchat = source[1]
                jid = get_true_jid(source[1]+'/'+source[2])
                if TESTIQP.has_key(source[1]):
                        if TESTIQP[source[1]].has_key(jid):
                                a = TESTIQP[source[1]][jid]['answer']
                                if parameters.lower() == a.lower():
                                        testiq_participant(source[1], source[2])
                                        
                                        threading.Thread(None,testiq_deluser,'iqs'+str(random.randrange(0,9999)),(groupchat, jid,)).start()
                                        
                                        msg(source[1]+'/'+source[2], TESTIQCONF[groupchat]['TESTIQBDTEXTWELCOME'])
                                else:
                                        if TESTIQP[source[1]][jid]['trials'] > 0:
                                                msg(source[1]+'/'+source[2], TESTIQCONF[groupchat]['TESTIQBDTEXTNOT'] % str(TESTIQP[source[1]][jid]['trials']))
                                                TESTIQP[source[1]][jid]['trials'] -= 1
                                        else:
                                                testiq_kick(source[1], source[2], TESTIQCONF[groupchat]['TESTIQBDTEXTNOTRESON'])

def testiq_check(type, source, parameters):
        DBPATH='Bot-Tools/'+source[1]+'/testiq.txt'
        if not parameters:
                if TESTIQCONF.has_key(source[1]):
                        if TESTIQCONF[source[1]]['TESTIQONOFF']:
                                a = u'تفعيل'
                        else:
                                a = u'تعطيل'
                else:
                        a = u'UNDEFINED'
                if TESTIQONOFFDEF:
                        b = u'تفعيل'
                else:
                        b = u'تعطيل'
                #res = u'IQ тест v0.3\nAuthor: Gigabyte\nIdea: ManGust\nStatus of plugin: '+a+u'\nQuestions in the IQ database: '+str(len(TESTIQCONF[source[1]]['TESTIQBD'].keys()))+u'\nStatus of the plugin by default: '+b+u'\nNumber of attempts: '+str(TESTIQCONF[source[1]]['TESTIQTRIALS'])
                res = u'حالة الامر الآن هي : '+a+u'\nعدد الاسئلة هو : '+str(len(TESTIQCONF[source[1]]['TESTIQBD'].keys()))+u'\nالحالة الافتراضية للأمر هي: '+b+u'\nعدد المحاولات هو : '+str(TESTIQCONF[source[1]]['TESTIQTRIALS'])
        else:
                if parameters == 'info':
                        #res = u'IQ test v0.3\nAuthor: Gigabyte\nIdea: ManGust\nHow this plugin works:\nThe bot give avisitor to any nick that do not have membership at the entrance, if user reply correct answer, then gets voice, if wrong reply in few times then gets kicked. The plugin has a setting in the configuration file (for admins bot)'
                        res = u'How this plugin works:\nThe bot give avisitor to any nick that do not have membership at the entrance and submit a question, if the user reply correct answer, then gets voice, if wrong reply in few times then gets kicked. The plugin has a setting in the configuration file (for admins bot)'
                elif parameters == 'تفعيل':
                        if not TESTIQCONF.has_key(source[1]):
                                TESTIQCONF[source[1]] = {'TESTIQBDTEXT': u'_اجب على السؤال التالى للحصول على حق التحدث فى الغرفة_',
                                                 'TESTIQBDTEXTWELCOME': u'الأن يمكنك التحدث فى الغرفة',
                                                 'TESTIQBDTEXTNOT': u'اجابه خاطئه :-( , محاوله: %s',
                                                 'TESTIQBDTEXTNOTRESON': u'اسف, اجابه خاطئه !',
                                                 'TESTIQBD': {u'3+4':'7',
                                                              u'3+7':u'10',
                                                              u'9-5':u'4',
                                                              u'7-3':u'4'},
                                                 'TESTIQONOFF': 1,
                                                 'TESTIQTRIALS': 3}
                        else:
                                TESTIQCONF[source[1]]['TESTIQONOFF'] = 1
                        write_file(DBPATH, str(TESTIQCONF[source[1]]))
                        res = u'تم تفعيل سؤال الخاص'
                elif parameters == 'تعطيل':
                        if not TESTIQCONF.has_key(source[1]):
                                TESTIQCONF[source[1]] = {'TESTIQBDTEXT': u'_اجب على السؤال التالى للحصول على حق التحدث فى الغرفة_',
                                                 'TESTIQBDTEXTWELCOME': u'الأن يمكنك التحدث فى الغرفة',
                                                 'TESTIQBDTEXTNOT': u'اجابه خاطئه :-( , محاوله: %s',
                                                 'TESTIQBDTEXTNOTRESON': u'اسف, اجابه خاطئه !',
                                                 'TESTIQBD': {u'3+4':'7',
                                                              u'3+7':u'10',
                                                              u'9-5':u'4',
                                                              u'7-3':u'4'},
                                                 'TESTIQONOFF': 0,
                                                 'TESTIQTRIALS': 3}
                        else:
                                TESTIQCONF[source[1]]['TESTIQONOFF'] = 0
                        write_file(DBPATH, str(TESTIQCONF[source[1]]))
                        res = u'تم الغاء سؤال الخاص'
                else:
                        res = u'صيغة خاطئة'
        reply(type, source, res)

def testiq_test(groupchat, nick):
        if groupchat in TESTIQP.keys():
                if get_true_jid(groupchat+'/'+nick) in TESTIQP[groupchat].keys():
                        return 1
        return 0

def testiq_set(type, source, parameters):
        if not parameters:
                reply(type, source, u'صيغة خاطئة')
                return

        DBPATH='Bot-Tools/'+source[1]+'/testiq.txt'
        mas = parameters.split(' ', 1)
        if len(mas) < 2:
                reply(type, source, u'صيغة خاطئة')
                return

        if mas[0] in ['TESTIQBDTEXT', 'TESTIQBDTEXTWELCOME', 'TESTIQBDTEXTNOT', 'TESTIQBDTEXTNOTRESON', 'TESTIQTRIALS']:
                if TESTIQCONF.has_key(source[1]):
                        if mas[0] == 'TESTIQTRIALS':
                                try:
                                        a = int(mas[1])
                                        a = a + 2
                                        TESTIQCONF[source[1]][mas[0]] = int(mas[1])
                                except:
                                        reply(type, source, u'This parameter accepts numeric only')
                                        return
                        else:
                                TESTIQCONF[source[1]][mas[0]] = mas[1]

                        write_file(DBPATH, str(TESTIQCONF[source[1]]))
                        reply(type, source, u'Saved')
        elif mas[0] == 'BD':
                if TESTIQCONF.has_key(source[1]):
                        # iq.set BD ADD tes tes tes|5
                        if 1==1:
                                bd1 = mas[1].split(' ', 1)
                                bd_param = bd1[0]
                                
                                
                                if bd_param == 'ADD':
                                        bd_otvet = bd1[1].split('|', 1)[1]
                                        bd_vopros = bd1[1].split('|', 1)[0]
                                        TESTIQCONF[source[1]]['TESTIQBD'][bd_vopros] = bd_otvet
                                        reply(type, source, u'Added')
                                        write_file(DBPATH, str(TESTIQCONF[source[1]]))
                                elif bd_param == 'GET':
                                        if len(bd1) >=2:
                                                try:
                                                        res = TESTIQCONF[source[1]]['TESTIQBD'].keys()[int(bd1[1])-1]
                                                        res += '|'+TESTIQCONF[source[1]]['TESTIQBD'][res]
                                                        reply(type, source, res)
                                                except:
                                                        reply(type, source, u'No such issue')
#                        except:
#                                reply(type, source, u'What is missing')
#                                return
                        



register_message_handler(testiq_message)
register_join_handler(testiq_join)
register_stage1_init(get_afools_state)
register_stage1_init(get_autoaway_state)
register_stage1_init(set_default_gch_status)
register_message_handler(handler_quiz_message)
register_join_handler(atjoin_greetz)
register_stage1_init(get_greetz)
register_stage1_init(get_order_cfg)
register_stage2_init(order_check_idle)
register_join_handler(atjoin_greetex)
register_message_handler(handler_order_message)
register_join_handler(handler_order_join)
register_leave_handler(handler_order_leave)
register_presence_handler(handler_order_presence)
register_stage1_init(get_commoff)
register_presence_handler(status_change)
register_stage0_init(get_access_levels)
register_command_handler(handler_killrooms, 'تصفير-رومات', ['الكل'],  200, '\nسحب البوت من جميع الرومات', 'مثال')
register_command_handler(allacc_del, 'تصفير-اكسز', ['الكل','المالك'], 200, '\nمسح جميع ايميلات الاكسز')
register_command_handler(handler_admin_exit, 'ايقاف', ['الكل'], 200, '\nايقاف البوت عن العمل')
#register_command_handler(handler_glob_msg_help, 'رسالة-جميع', ['الكل'], 200, 'إرسال رسالة إلى جميع conf ، والتي بوت في.', 'رسالة-جميع [الرسالة]', [''])
register_command_handler(handler_changebotstatus, 'حالة-البوت', ['الكل'], 200, '\nتغيير حالة البوت في الغرفة\nالقيم المتاحة لوضع الحالات chat | dnd | xa | away\nحالة-البوت xa New Arabic Bot By SyriaTalk.org')
register_command_handler(handler_access_set_access_glob, 'منح-اكسز', ['الكل'], 200, '\nمنح اكسز في البوت\nمنح-اكسز ahmed@syriatalk.org 200')
register_command_handler(handler_access_del_access_glob, 'مسح-اكسز', ['الكل'], 200, '\nمسح الاكسز في البوت\nمسح-اكسز ahmed@syriatalk.org')
register_command_handler(admin_getglobadmins, 'قائمة-اكسز', ['الكل'], 200, '\nعرض الحسابات التي لها اكسز في البوت')
register_command_handler(handler_admin_join, 'اذهب', ['الكل'], 100, '\nارسال البوت الى غرفة')
register_command_handler(handler_admin_leave, 'غادر', ['الكل'], 100, '\nسحب البوت من غرفة ')
register_command_handler(handler_glob_msg, 'رسالة-رومات', ['الكل'], 100, '\nارسال رسالة الى الغرف الموجود فيها البوت')
register_command_handler(handler_remote, 'رومات', ['الكل'],  100, '\nعرض الرومات الموجود بها البوت')
register_command_handler(roster_show, 'قائمة-الاضافات', ['الكل'], 100, '\nعرض اضافات البوت')		
register_command_handler(roster_sub, 'اضف-ايميل', ['الكل'], 100, '\nاضافة حساب عن كريق البوت.')
register_command_handler(roster_unsub, 'حذف-ايميل', ['الكل'], 100, '\nمسح اضافة من البوت.')
register_command_handler(handler_admin_msg, 'رسالة-ايميل', ['الكل'], 100, '\nارسال رسالة عن طريق البوت الى حساب')
register_command_handler(handler_admin_restart, 'ريستارت', ['الكل'], 100, '\nاعادة تشغيل البوت')
register_command_handler(handler_quiz_base_del, '!base_del', ['all'], 100, '')
register_command_handler(handler_commoff, 'تعطيل-امر', ['الكل'], 30, '\nتعطيل امر معين في البوت')
register_command_handler(handler_common, 'تفعيل-امر', ['الكل'], 30, '\nتفعيل امر تم تعطيله في البوت')
register_command_handler(handler_order_filt, 'filter', [''], 30, '\nهذا الامر خاص بفلاتر البوت و هي :\nfilter time : فلتر الرسائل السريعة\nfilter presence : فلتر تغيير الحالة بسرعة\nfilter len : فلتر الاسم الطويل\nfilter like : فلتر الشك ﻻيقاف اي شخص مشتبه به بالغرفة\nfilter caps : فلتر الحروف الكبيرة\nfilter prsstlen : فلتر الحالة الطويلة\nfilter arabic : فلتر السب والاعلان\nfilter fly : فلتر الدخول والخروج بسرعة\nfilter kicks : فلتر الطرد\nfilter idle : فلتر عدم المشاركة\nو تفعيل او تعطيل واحد من هذه الفلاتر يكون بوضع [ on او off ] بعد اسم الفلتر\nللتفعيل : filter arabic on\nللتعطيل : filter arabic off\nو بقية الفلاتر هكذا')
register_command_handler(handler_greetex, 'ترحيب', ['الكل'], 30, '\nاضافة ترحيب الى رتبة في الروم القيم المتاحة\nnone | member | admin | owner\nترحيب owner=hello %NICK% welcome')
register_command_handler(handler_greet, 'ترحيب-ايميل', ['الكل'], 30, '\nاضافة ترحيب لشخص عن طريق حسابه\nترحيب-ايميل gg@server.sy اهلا وسهلآ')
register_command_handler(handler_bot_nick, 'اسم-البوت', ['الكل'],  30, '\nامر لتغيير اسم البوت في الروم')
register_command_handler(handler_admin, 'مدير', ['الكل'],  30, '\nاضافة شخص الى قائمة المدراء في الغرفة عن طريق البوت ملاحظة يجب ان يكون البوت اونر')
register_command_handler(handler_owner, 'اونر', ['الكل'],  30, '\nاضافة شخص الى قائمة الاونرات في الغرفة عن طريق البوت ملاحظة يجب ان يكون البوت اونر')
register_command_handler(handler_botautoaway_onoff, 'حالة-تلقائية', ['الكل'], 30, '\nحالة تلقائية تظهر عندما لا يتلقى البوت الاوامر\nللتشغيل : حالة-تلقائية 1\nللتعطيل : حالة-تلقائية 0')
register_command_handler(handler_admin_say, 'قول', ['الكل'], 30, '\nالتحدث في الروم عن طريق البوت\nقول هاي')
register_command_handler(handler_poke_add, 'نكز+', ['الكل'], 30, '\nلاضافة عبارة معينة لامر نكز\nنكز+ رد علينا')
register_command_handler(handler_poke_del, 'نكز-', ['الكل'], 30, '\nلحذف عبارة معينة تم اضافتها لامر النكز')
register_command_handler(handler_poke_list, 'نكز*', ['الكل'], 30, '\nلعرض العبارات التي تم اضافتها لامر نكز عن طريق الادمن')
#register_command_handler(testiq_set, 'iq.set', ['admin','all'], 20, 'Setup test IQ: edit configuration. Available keys:\nTESTIQBDTEXT - Greeting text\nTESTIQBDTEXTWELCOME - greeting text in the case of a correct answer\nTESTIQBDTEXTNOT - text in the case not the correct answer. May contain "%s" it will be replaced by number of remaining attempts\nTESTIQBDTEXTNOTRESON - text reason of kick\nTESTIQTRIALS - number of attempts to answer', 'iq', ['iq','iq yes'])
register_command_handler(testiq_check, 'سؤال', ['الكل'], 30, '\nهذا الامر يستخدم وقت الضرورة وهو يقوم بسحب حق التحدث من الزوار و ارسال سؤال الى الخاص\nاذا تمت الاجابة عنه يمنح حق التحدث و إلا فيقوم بطرد الزائر\nوهذا لمنع بوتات الفلود و الرسائل التلقائية\n\nسؤال تفعيل | سؤال تعطيل')
#register_command_handler(handler_afools_control, 'نكات', ['الكل'], 30, 'تفعيل النكات المرحه فى الروم')
register_command_handler(handler_ban, 'فصل', ['الكل'],  20, '\nفصل شخص داخل الروم عن طريق لقبه او حسابه')
register_command_handler(handler_ban, 'ف', ['الكل'], 20, '\nفصل شخص داخل الروم عن طريق لقبه او حسابه')
register_command_handler(handler_visitor, 'صامت', ['الكل'],  20, '\nسحب حق التحدث من شخص داخل الروم عن طريق لقبه او حسابه')
register_command_handler(handler_participant, 'مشارك', ['الكل'],  20, '\nاعطاء حق التحدث لشخص داخل الروم عن طريق اللقب او الحساب')
register_command_handler(handler_kick, 'ط', ['الكل'], 20, '\nطرد شخص من الروم عن طريق لقبه او حسابه')
register_command_handler(handler_kick, 'طرد', ['الكل'],  20, '\nطرد شخص من الروم عن طريق لقبه او حسابه')
register_command_handler(handler_member, 'عضو', ['الكل'],  20, '\nاعطاء عضويه في الروم عن طريق القب او الحساب')
register_command_handler(handler_unban, 'فك-فصل', ['الكل'], 20, 'لإلغاء حظر شخص من المؤتمر')
register_command_handler(handler_cleaner, 'نظف', ['الكل'], 20, 'امر خاص بتنظيف الروم')
register_command_handler(handler_cleaner, 'ن', ['الكل'], 20, 'امر خاص بتنظيف الروم')
register_command_handler(handler_getrealjid, 'ايميل', ['الكل'], 20, '\nعرض حساب شخص في روم عن طريق لقبه\nايميل فايروس')
register_command_handler(handler_total_in_muc, 'هنا', ['الكل'], 20, '\nعرض المستخدمين الحالين في الروم')
register_command_handler(handler_bot_uptime, 'وقت-البوت', ['الكل'],  20, '\nعرض وقت عمل البوت')
register_command_handler(handler_aff, 'قائمة', ['الكل'], 20, '\nعرض الحسابات الموجودة في القوائم\nالقيم المتاحة للأمر \nالاونرات | الادمن | المفصولين | الاعضاء')
register_command_handler(handler_invite_start, 'دعوة', ['الكل'],  11, '\nارسال دعوة لشخص كان في الروم عن طريق لقبه او حسابه\nدعوة فايروس')
register_command_handler(handler_poke, 'نكز', ['الكل'], 11, '\nامر لمحاولة ايقاظ احد المشتركين من خلال هزة جواله\nنكز درش')
register_command_handler(handler_quiz_start, 'بدء-مسابقة', ['quiz'], 11, '')
register_command_handler(handler_quiz_help, 'مسابقة', ['الكل'], 11, '\nلعبة عبارة عن مجموعة اسئلة و يتم الاجابة عنها')
register_command_handler(handler_quiz_resend, 'اعادة-السؤال', ['all'], 11, '')
register_command_handler(handler_quiz_stop, 'ايقاف-مسابقة', ['all'], 11, '')
register_command_handler(handler_quiz_hint, 'نلميح', ['all'], 11, '')
register_command_handler(handler_quiz_scores, 'النتيجة', ['all'], 11, '')
register_command_handler(handler_quiz_next, 'السؤال-التالي', ['all'], 11, '')
register_command_handler(handler_quiz_answer, 'الاجابة', ['all'], 11, '')
register_command_handler(handler_status, 'ح', ['الكل','الاعضاء'], 11, '\nعرض حالة شخص في الروم')
register_command_handler(handler_status, 'حالة', ['الكل','الاعضاء'], 11, '\nعرض حالة شخص في الروم')
register_command_handler(handler_version, 'نسخة', ['الكل','الاعضاء'], 11, '\nعرض نسخة شخص ما في الروم او نسختك الشخصية')
register_command_handler(handler_help_help, 'مساعدة', ['الكل'], 0, '\nللمساعدة في امر معين\nمساعدة ترحيب')
register_command_handler(handler_help_help, 'help', [''], 0, '\nللمساعدة في امر معين\nhelp filt')
register_command_handler(handler_command_list, 'الاوامر', ['الكل'], 0, '\nلمعرفة اوامر البوت')
register_command_handler(handler_vortex_1, 'شعور', ['الكل'], 0, '\nامر تسلية في الروم')
register_command_handler(handler_vortex_2, 'مستقبل', ['الكل'], 0, '\nامر تسلية في الروم')
register_command_handler(handler_love, 'الحب', ['الكل'], 0, '\nامر تسلية في الروم')
register_command_handler(handler_heat, 'الكره', ['الكل'], 0, '\nامر تسلية في الروم')
register_command_handler(handler_hug, 'عبوطة', ['الكل'], 0, '\nامر عبوطة لروح المرح بالروم\nعبوطة درش')
register_command_handler(handler_kiss, 'بوس', ['الكل'], 0, '\nامر بوس لروح المرح بالروم\nبوس درش')
register_command_handler(handler_love, 'طبقلي', ['الكل'], 0, '\nامر طبقلي لروح المرح بالروم\nطبقلي درش')
register_command_handler(handler_success, 'نجاح', ['الكل'], 0, '\nكلمات تحفيزية من التنمية البشرية للعالم الاستاذ / ابراهيم الفقي')
register_command_handler(handler_flirt, 'شوق', ['الكل'], 0, '\nامر لخلق روح الدعابة في الروم')
register_command_handler(handler_access_view_access, 'اكسز', ['الكل'], 0, '\nمعرفة مستوى الاكسز الخاص بك')
register_command_handler(handler_ping, 'سرعة', ['الكل'],  0, '\nعرض سرعة الشبكه')
register_command_handler(handler_test, 'تست', ['الكل'], 0, '\nامر خاص لاختبار البوت')
#######################################
