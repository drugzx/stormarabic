#!/bin/sh

cd /sdcard/isi3 && python isida.py &
