#!/usr/bin/python
# -*- coding: utf-8 -*-
# Plugin Tarfeh.py
# Edite By Programmer Sawim
# Edite By Programmer Vortex
# For Quiz BoT © 2020

reload(sys).setdefaultencoding("utf-8")

def shrh(type, jid, nick): 
    shrh = [u'اهلا بكم في الاصدار السادس من بوت ISIDA\n__________\n\nالقيم التي تطبق على الفلاتر كالتالي :\n\non = تفعيل\noff = تعطيل\nreplace = تشفير\nmute = حجب\nban = فصل\nkick = طرد\n_____________\n1-filter \n لعرض فلاتر البوت\n______\n2- filter censor\nفلتر الكلمات السيئة \nالقيم التي يأخذخا\nreplace - mute - off\n_______\n2- filter change_nick\nفلتر تغيير اسماء الذوار\nالقيم التي يأخذها\non - off\n_______\n3- filter like\nفلتر استبدال  الشتائم\nالقيم التي يأخذها\non - off\n_______\n4- filter msg\nلحجب الرساله الاطول من 40 حرف\nالقيم التي يأخذخا\nreplace - mute - off\n________\n5- filter nick\nلحجب اللقب الاطول من 9 احرف\nالقيم التي يأخذها\nreplace - mute - off\n________\n6- filter rejoin\nاعادة الانضمام بسرعه\nالقيم التي يأخذها\nban - kick - mute - off\n________\n7-filter repeat\n تكرار الرساله\nالقيم التي يأخذها\nkick - ban - mute - off\n________\n8- filter s_msg\nالفراغات الكثيرة بالرساله\nالقيم التي يأخذها\non - off\n________\n9- filter s_prs\nالفراغات الكثيره باللقب\nالقيم التي ياخذها\non - off\n________\n10- filter tkrar\nمنع تكرار الاحرف بالرساله\nالقيم التي ياخذها\nmute - off\n________\n11- filter tkrae_prs\nحجب تكرار الحاله\nالقيم.التي ياخذها\nkick - ban - mute - off\n________\n12- filter tmdad\nحجب التمديد بالرساله\nالقيم التي يأخذها\non - off\n_______\nلعرض كل الفلاتر مع القيم المطبقه عليه اكتب\n\nfilter show status\n\n____isida v6____']
    send_msg(type, jid, nick, random.choice(shrh))

global execute

execute = [(1, 'شرح-فلتر'.decode('utf8'), shrh, 1, 'شرح فلاتر البوت')]
