#!/usr/bin/python
# -*- coding: utf-8 -*-
##
#    Plugin for iSida Jabber Bot#
#    Copyright (C) diSabler <telGram → @ejabberd_bots>#
from urllib2 import quote
import urllib, re
def youtube(type, jid, nick, text):
	if text:
		try:
			html = urllib.urlopen("https://youtube.com/results?search_query=" + quote(text.encode("utf-8")))
			video_ids = re.findall(r"watch\?v=(\S{11})", html.read().decode())
			msg = "\n\n'{}'\n\nhttps://youtu.be/{}".format(text, video_ids[0])
		except:
			msg = "حاول لاحقاً"
	else:
		msg = "اكتب عنوان الفديو"
	send_msg(type, jid, nick, msg)
global execute
execute = [(3, u'يوتيوب', youtube, 2, 'البحث في يوتيوب')]
