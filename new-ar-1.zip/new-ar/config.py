# -*- coding: utf-8 -*-
#New Arabic Bot Ver 3
#Powered By ahmed & darsh
#when you want to edit this file , only mention vaeros & darsh
{
# --------------------------------------------------------------------------- #
#-----------------------------بيانات ثابتة في البوت-----------------------------#
'CONNECT_SERVER': 'syriatalk.org',
'PORT': 5222,
'ADMINS': [u'ahmed@syriatalk.org',u'darsh@syriatalk.org'],
'ADMIN_PASSWORD': 'byevilteam',
'AUTO_RESTART': 100,
'RESOURCE': 'AraBic',
# --------------------------------------------------------------------------- #
#-----------------------------بيانات متغيرة في البوت-----------------------------#
#ايميل البوت بدون السيرفر
'JID': 'arabic.darsh',
#-----------------------------#
#الباسورد
'PASSWORD': '123456a',
#-----------------------------#
#اسم البوت في الرومات
'DEFAULT_NICK': '[ D ] AraBic',
#-----------------------------#
#حالة البوت في الرومات
'Bot_Status': [
u'online' ,
u'''
Powered By
♡ ḓαяṣн ♡
darsh@syriatalk.org
''']}
