#!/usr/bin/env python
# -*- coding: utf-8 -*-
from codes import *

if __name__ == '__main__':
    try:
        starts()
    except KeyboardInterrupt:
        print 'Error'
