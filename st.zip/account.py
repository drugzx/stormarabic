# STRONG BOT V 1.1
# ♡ ḓαяṣн ♡ : darsh@syriatalk.org
# _◦̃»̃↨άł-ΰάέřόŝ↨«̃◦̃_ : ahmed@syriatalk.org
####################################

#حساب البوت كامل مع السيرفر
Bot_jid = pvplucy@jabber.ru
#باسورد حساب البوت
Bot_pass = pjzfkbsb22
