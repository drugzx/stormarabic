# -*- coding: utf-8 -*-
#
#
# STRONG BOT V 1.1
# ♡ ḓαяṣн ♡ : darsh@syriatalk.org
# _◦̃»̃↨άł-ΰάέřόŝ↨«̃◦̃_ : ahmed@syriatalk.org
####################################
#اختيار لغة البوت
BOT_lanG = "ar"
#بورت البوت
Port = 5222
#ريسورس البوت
BoTRiS = "STRONG_BOT"
#ادمن البوت
ADMINS = ["aboabdelmalek@xmpp.ru"]
#الروم الرئيسية للبوت
Room = "egypt-syria@conference.jabber.ru"

#اسم البوت
BoTNicK = "ṣţяσηģ"
#حالة البوت
Status =  """
Powered By
♡ ḓαяṣн ♡
"""




