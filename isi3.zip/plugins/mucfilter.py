#!/usr/bin/python
# -*- coding: utf-8 -*-

speed = {}
fast_join = {}
last_notify = 0
events = []

def muc_pprint(*param):
	global events,last_notify
	pprint(*param)
	if GT('notify'):
		_notify_count = GT('notify_count')
		events = [time.time()] + events[:_notify_count-1]		
		if len(events) == _notify_count \
				and events[0] - events[-1] < GT('notify_peroid') \
				and last_notify + GT('notify_wait') < time.time():
			pprint('*** MUC-Filter notify event!')
			last_notify = time.time()
			events = []
			_jids = GT('notify_jids').split()
			for t in _jids:
				if t.strip(): send_msg('chat', t.strip(), '', 'MUC-Filter Linus')

def muc_set(iq,id,room,acclvl,query,towh,al):
	msg_xmpp = iq.getTag('query', namespace=xmpp.NS_MUC_FILTER)
	if msg_xmpp:
		msg,mute,mute_type,mute_room = get_tag(unicode(msg_xmpp),'query'),None,'groupchat',room
		jid = rss_replace(get_tag_item(msg,'message','from'))
		nick = rss_replace(unicode(get_nick_by_jid_res(room,jid)))
		rn = '%s/%s' % (room,nick)
		mute_reason = L('تم حظر رسالتك بأمر من\n ιѕιđα @}->--',rn)
		if msg[:2] == '<m':
			if '<body>' in msg and '</body>' in msg:
				to_nick = getResourse(get_tag_item(msg,'message','to'))
				tojid = rss_replace(getRoom(get_level(room,to_nick)[1]))
				skip_owner = is_owner(jid)
				gr = getRoom(room)
				type = get_tag_item(msg,'message','type')
				if type == 'chat' and not skip_owner:
					tmp = cur_execute_fetchall('select * from muc_lock where room=%s and jid=%s', (room,tojid))
					if tmp:
						mute,mute_type,mute_room,mute_reason = True,'chat', '%s/%s' % (room,to_nick),L('خاص هذا المشترك مغلق',rn)
						muc_pprint('MUC-Filter pmlock: %s/%s [%s] > %s: %s' % (room,nick,jid,to_nick,get_tag(msg,'body')),'brown')
				if skip_owner: pass
				elif get_config(gr,'muc') and not mute:
					body = get_tag(msg,'body')

					# Mute all private messages
					if not mute and msg and type == 'chat' and get_config(gr,'رسائل-الخاص'):
						muc_pprint('MUC-Filter lock private: %s/%s [%s] > %s: %s' % (room,nick,jid,to_nick,get_tag(msg,'body')),'brown')
						try: cnt = mute_msg['%s|%s' % (gr,jid)]
						except: cnt = 1
						act = get_config(gr,'التكرار')
						if act != 'off':
							if cnt >= get_config_int(gr,'عدد-تكرار-الرسائل'):
								muc_pprint('MUC-Filter mute repeat action (%s): %s %s [%s]' % (act,gr,jid,cnt),'brown')
								msg = action(act,jid,room,L('تم حظر الرسالة بسسب الكثير من المعلومات المرسلة\n ιѕιđα @}->--!!',rn))
							else: mute_msg['%s|%s' % (gr,jid)] = cnt + 1
						mute,mute_type,mute_room,mute_reason = True,'chat', '%s/%s' % (room,to_nick),L('لا يمكنك الارسال مجدداً في الخاص \n ιѕιđα @}->--!!',rn)

					# Mute all public messages
					if not mute and msg and type == 'groupchat' and get_config(gr,'رسائل-العام'):
						muc_pprint('MUC-Filter lock public: %s/%s [%s] > %s' % (room,nick,jid,get_tag(msg,'body')),'brown')
						try: cnt = mute_msg['%s|%s' % (gr,jid)]
						except: cnt = 1
						act = get_config(gr,'التكرار')
						if act != 'off':
							if cnt >= get_config_int(gr,'عدد-تكرار-الرسائل'):
								muc_pprint('MUC-Filter mute repeat action (%s): %s %s [%s]' % (act,gr,jid,cnt),'brown')
								msg = action(act,jid,room,L('Muted messages count overflow!',rn))
							else: mute_msg['%s|%s' % (gr,jid)] = cnt + 1
						mute,mute_reason = True,L('لا يمكنك الارسال مجدداً في العام \n ιѕιđα @}->--!!',rn)

					# Reduce spaces
					if not mute and msg and get_config(gr,'s_msg') and '  ' in body:
						muc_pprint('MUC-Filter msg reduce spaces: %s [%s] %s' % (jid,room,nick+'|'+body),'brown')
						body = reduce_spaces_all(body)
						msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)

# New Filter By Sawim & Vortex
					if not mute and msg and get_config(gr,'tmded') and 'ـ' in body:
						muc_pprint('pro sawim: %s [%s] %s' % (jid,room,nick+'|'+body),'brown')
						body = body.replace('ـ','')
						msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)

# New Filter By Sawim And Vortex
					if not mute and msg and get_config(gr,'like'):
						muc_pprint('pro vortex: %s [%s] %s' % (jid,room,nick+'|'+body),'brown')
						body = body.replace('نايك','انا منيوك').replace('امككك','امي').replace('ـ','').replace('كلنتون','').replace('طيز','').replace('شرمط','انا جحش').replace('كلب','عوعووو').replace('ينتاك','امي تنتاك ').replace('طﻱﺯ','خلفية امي').replace('ﻱنيك','عوعووو').replace('اختك','اختي').replace('ْ','').replace('ً','').replace('ُ','').replace('ٌ','').replace('ِ','').replace('ٍ','').replace('ْ','').replace('عيلتك','عيلتي').replace('قوطك','قوطي').replace('كسك','كسي').replace('طيز','طيزي').replace('عاهره','انا عاهر').replace('شرموط','انا شرموط').replace('شرمووط','انا شرموط').replace('شرمووو','عوعوعو').replace('قحبه','انا قحب').replace('قحبة','انا قحب').replace('قححبب','انا قحببه').replace('شلكه','انا شلكه').replace('شلكة','انا شلكة').replace('كووس','كوسي').replace('كؤؤس','كس امي').replace('طيز','تمي').replace('طييز','عوعو').replace('شاخخ','شاخخ عحالي').replace('منيوك','انا منيوك').replace('ايري','عوعو').replace('محبل','محبل حالي').replace('حالب','عوعو').replace('امممك','امي').replace('اخختك','اختي').replace('نايش','نايش حالي').replace('ايييير','ايري بحالي')
						msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)


					# AD-Block - الاعلان
					need_raw = True
					if not mute and msg and get_config(gr,'tkrar') != 'off':
						f = []
						for reg in adblock_regexp:
							tmp = re.findall(reg,body,re.S|re.I|re.U)
							if tmp: f = f + tmp
						if f:
							act = get_config(gr,'tkrar')
							need_raw = False
							muc_pprint('MUC-Filter msg adblock (%s): %s [%s] %s' % (act,jid,room,body),'brown')
							if act == 'replace':
								for tmp in f: body = body.replace(tmp,[GT('censor_text')*len(tmp),GT('censor_text')][len(GT('censor_text'))>1])
								msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)
							elif act == 'mute': mute,mute_reason = True,L('فلتر تكرار الاحرف \n ιѕιđα @}->--!!',rn)
							else: msg = action(act,jid,room,L('فلتر تكرار الاحرف \n ιѕιđα @}->--!!',rn))

		
					# Repeat message - التكرار
					if not mute and msg and get_config(gr,'repeat') != 'off':
						grj = getRoom(jid)
						try: lm = last_msg_base[grj]
						except: lm = None
						if lm:
							rep_to = GT('repeat_time')
							try: lmt = last_msg_time_base[grj]
							except: lmt = 0
							if rep_to+lmt > time.time():
								action = False
								if body == lm: action = True
								elif lm in body:
									try: muc_repeat[grj] += 1
									except: muc_repeat[grj] = 1
									if muc_repeat[grj] >= (GT('repeat_count')-1): action = True
								else: muc_repeat[grj] = 0
								if action:
									act = get_config(gr,'repeat')
									muc_pprint('MUC-Filter msg repeat (%s): %s [%s] %s' % (act,jid,room,body),'brown')
									if act == 'mute': mute,mute_reason = True,L('تكرار الرسالة ممنوع \n ιѕιđα @}->--!!',rn)
									else: msg = action(act,jid,room,L('تكرار الرسالة ممنوع \n ιѕιđα @}->--!!',rn))
							else: muc_repeat[grj] = 0
						last_msg_base[grj] = body
						last_msg_time_base[grj] = time.time()


					# Censor filter
					need_raw = True
					if not mute and msg and get_config(gr,'censor') != 'off' and esc_min2(body) != to_censore(esc_min2(body),gr):
						act = get_config(gr,'censor')
						need_raw = False
						muc_pprint('MUC-Filter msg censor (%s): %s [%s] %s' % (act,jid,room,body),'brown')
						if act == 'replace': msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % esc_max2(to_censore(esc_min2(body),gr)))
						elif act == 'mute': mute,mute_reason = True,L('ممنوع \n ιѕιđα @}->--!!',rn)
						else: msg = action(act,jid,room,L('ممنوع \n ιѕιđα @}->--!!',rn))

					# Large message filter
					if not mute and msg and get_config(gr,'msg') != 'off' and len(body) > GT('large_message_size'):
						act = get_config(gr,'msg')
						muc_pprint('MUC-Filter msg large message (%s): %s [%s] %s' % (act,jid,room,body),'brown')
						if act == 'replace':
							url = paste_text(rss_replace(body),room,jid)
							if act == 'replace': body = u'%s\nتم حجب باقي الرسالة\nιѕι∂α-ν6 %s' % (body[:GT('large_message_size')],'')
							else: body = L('Large message%s %s',rn) % (u'…',url)
							msg = msg.replace(get_tag_full(msg,'body'),'<body>%s</body>' % body)
						elif act == 'mute': mute,mute_reason = True,L('_الرسالة الكبيرة ممنوعة_ \n ιѕιđα @}->--!!',rn)
						else: msg = action(act,jid,room,L('_الرسالة الكبيرة ممنوعة_ \n ιѕιđα @}->--!!',rn))

				if mute: msg = unicode(xmpp.Message(to=jid,body=mute_reason,typ=mute_type,frm=mute_room))
			else: msg = None

		elif msg[:2] == '<p':
			jid = rss_replace(get_tag_item(msg,'presence','from'))
			gr = getRoom(room)
			if server_hash_list.has_key('%s/%s' % (gr,getServer(jid))) or server_hash_list.has_key('%s/%s' % (gr,getRoom(jid))):
				muc_pprint('MUC-Filter sawim by previous ban: %s %s' % (room,jid),'brown')
				return True

			tojid = rss_replace(get_tag_item(msg,'presence','to'))
			if is_owner(jid): pass
			elif get_config(gr,'muc') and not mute:
				show = ['online',get_tag(msg,'show')][int('<show>' in msg and '</show>' in msg)]
				if show not in ['chat','online','away','xa','dnd']: msg = msg.replace(get_tag_full(msg,'show'), '<show>online</show>')
				status = ['',get_tag(msg,'status')][int('<status>' in msg and '</status>' in msg)]
				nick = ['',tojid[tojid.find('/')+1:]]['/' in tojid]
				newjoin = True
				for tmp in megabase:
					if tmp[0] == gr and tmp[4] == jid:
						newjoin = False
						break

		

				# Reduce spaces
				if not mute and msg and get_config(gr,'s_prs') and ('  ' in status or '  ' in nick):
					muc_pprint('MUC-Filter prs reduce spaces: %s [%s] %s' % (jid,room,nick+'|'+status),'brown')
					if len(status):
						status = reduce_spaces_all(status)
						msg = msg.replace(get_tag_full(msg,'status'),'<status>%s</status>'  % status).replace(esc_max2(tojid),'%s/%s' % (tojid.split('/',1)[0],reduce_spaces_all(esc_max2(nick))))
					else: msg = msg.replace(esc_max2(tojid),'%s/%s' % (tojid.split('/',1)[0],reduce_spaces_all(esc_max2(nick))))



				# Large status filter
				if not mute and msg and get_config(gr,'status') != 'off' and len(esc_min2(status)) > GT('large_status_size'):
					act = get_config(gr,'status')
					muc_pprint('MUC-Filter large status (%s): %s [%s] %s' % (act,jid,room,status),'brown')
					if act == 'replace': msg = msg.replace(get_tag_full(msg,'status'),u'<status>%s \nالروم في وضعية الفلترة تم حجب باقي الحالة \n ιѕιđα @}->--!!</status>' % esc_max2(esc_min2(status)[:GT('large_status_size')]))
					elif newjoin: msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('_الحالة الطويلة ممنوعة_ \n ιѕιđα @}->--!!',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
					elif act == 'mute': msg,mute = None,True
					else: msg = action(act,jid,room,L('_الحالة الطويلة ممنوعة_ \n ιѕιđα @}->--!!',rn))


				# Large nick filter
				if not mute and msg and get_config(gr,'nick') != 'off' and len(esc_min2(nick)) >= GT('large_nick_size'):
					act = get_config(gr,'nick')
					if act == 'replace': msg = msg.replace(esc_max2(tojid),u'%s/isida_|%s|' % (tojid.split('/',1)[0],esc_max2(esc_min2(jid)[:GT('large_nick_size_2')])))
					elif newjoin: msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('_الأسم الطويل ممنوع_ \n ιѕιđα @}->--!!',rn)])])])).replace('replace_it',get_tag(msg,'presence')),True
					elif act == 'mute': msg,mute = None,True
					else: msg = action(act,jid,room,L('تم منع دخولك بسبب اللقب الطويل',rn))


                   # Large nick filter
				if not mute and msg and get_config(gr,'change_nick') != 'off' and len(esc_min2(status)) >= GT('security_value'):
					act = get_config(gr,'change_nick')
					muc_pprint('MUC-Filter large status (%s): %s [%s] %s' % (act,jid,room,status),'brown')
					vortex = "isida|%s|" % (random.randrange(0,99))
					sawim = "#"
					yousef = "visitor"
					if act == 'all': msg = """<presence from="%s" to="%s/%s" ver="isida BoT" xml:lang="yazan"><show>dnd</show><status> الروم في وضع الحماية ιѕιđα </status><isida/><syria xmlns="syria"/><x xmlns="vcard-temp:x:update"/><x xmlns="http://jabber.org/protocol/muc%suser"><item affiliation="none" role="%s"/><status code="110"/></x></presence>""" % (jid,room,vortex,sawim,yousef)
					vorte = "isida|%s|" % (random.randrange(0,99))
					sawi = "#"
					youse = "visitor"
					if act == 'all': msg = """<presence from="%s" to="%s/%s" ver="isida BoT" xml:lang="yazan"><show>dnd</show><status> الروم في وضع الحماية ιѕιđα </status><isida/><syria xmlns="syria"/><x xmlns="vcard-temp:x:update"/><x xmlns="http://jabber.org/protocol/muc%suser"><item affiliation="none" role="%s"/><status code="110"/></x></presence>""" % (jid,room,vorte,sawi,youse)
					   
				
					
				# Rejoin filter
				if not mute and msg and get_config(gr,'اعادة-الانضمام') and newjoin:
					ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					try: muc_rejoins[ttojid] = [muc_rejoins[ttojid],muc_rejoins[ttojid][1:]][len(muc_rejoins[ttojid])==GT('rejoin_count')] + [int(time.time())]
					except: muc_rejoins[ttojid] = []
					if len(muc_rejoins[ttojid]) == GT('rejoin_count'):
						tmo = muc_rejoins[ttojid][GT('rejoin_count')-1] - muc_rejoins[ttojid][0]
						if tmo < GT('rejoin_timeout'):
							msg,mute = unicode(xmpp.Node('presence', {'from': tojid, 'type': 'error', 'to':jid}, payload = ['replace_it',xmpp.Node('error', {'type': 'auth','code':'777'}, payload=[xmpp.Node('forbidden',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[]),xmpp.Node('text',{'xmlns':'urn:ietf:params:xml:ns:xmpp-stanzas'},[L('_فلتر اعادة الدخول بسرعة انتظر مدة_ %s ثانية',rn) % GT('rejoin_timeout')])])])).replace('replace_it',get_tag(msg,'presence')),True
							muc_pprint('MUC-Filter rejoin: %s [%s] %s' % (jid,room,nick),'brown')

				# Status filter
				if not mute and msg and get_config(gr,'tkrar_prs') != 'off' and not newjoin:
					ttojid = '%s|%s' % (getRoom(tojid),getRoom(jid))
					try: muc_statuses[ttojid] = [muc_statuses[ttojid],muc_statuses[ttojid][1:]][len(muc_statuses[ttojid])==GT('status_count')] + [int(time.time())]
					except: muc_statuses[ttojid] = []
					if len(muc_statuses[ttojid]) == GT('status_count'):
						tmo = muc_statuses[ttojid][GT('status_count')-1] - muc_statuses[ttojid][0]
						if tmo < GT('status_timeout'):
							act = get_config(gr,'repeat_prs')
							muc_pprint('MUC-Filter status (%s): %s [%s] %s' % (act,jid,room,nick),'brown')
							if act == 'mute': msg,mute = None,True
							else: msg = action(act,jid,room,L('_تكرار الحالة ممنوع_\n ιѕιđα @}->--!!',rn))
							
		if msg:
			i=xmpp.Iq(to=room, typ='result')
			i.setAttr(key='id', val=id)
			i.setTag('query',namespace=xmpp.NS_MUC_FILTER).setTagData(tag='message', val='')
			try: return unicode(i).replace('<message />',msg)
			except: pass

	return None

global iq_hook

iq_hook = [[200,'set', muc_set]]
